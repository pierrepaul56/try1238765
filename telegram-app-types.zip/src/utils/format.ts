// ==========================================
// BANTAH - Formatting Utilities
// ==========================================

/**
 * Format amount as Nigerian Naira
 * @example formatBalance(1234.56) → "₦1,234.56"
 */
export function formatBalance(amount: number): string {
  return `₦${amount.toLocaleString("en-NG", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`
}

/**
 * Format coin balance with K/M suffixes
 * @example formatCoinBalance(1500) → "1.5K"
 * @example formatCoinBalance(500) → "500"
 */
export function formatCoinBalance(coins: number): string {
  if (coins >= 1_000_000) {
    return `${(coins / 1_000_000).toFixed(1).replace(/\.0$/, "")}M`
  }
  if (coins >= 1_000) {
    return `${(coins / 1_000).toFixed(1).replace(/\.0$/, "")}K`
  }
  return coins.toString()
}

/**
 * Truncate username with ellipsis
 * @example truncateUsername("verylongusername", 8) → "verylong..."
 */
export function truncateUsername(username: string, maxLength = 12): string {
  if (username.length <= maxLength) return username
  return `${username.slice(0, maxLength)}...`
}

/**
 * Get human-readable time remaining
 * @example getTimeRemaining(deadline) → "2h 30m remaining"
 */
export function getTimeRemaining(deadline: Date | string): string {
  const target = typeof deadline === "string" ? new Date(deadline) : deadline
  const now = new Date()
  const diff = target.getTime() - now.getTime()

  if (diff <= 0) return "Expired"

  const days = Math.floor(diff / (1000 * 60 * 60 * 24))
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))

  if (days > 0) return `${days}d ${hours}h remaining`
  if (hours > 0) return `${hours}h ${minutes}m remaining`
  return `${minutes}m remaining`
}

/**
 * Get category color for events
 */
export function getCategoryColor(category: string): string {
  const colors: Record<string, string> = {
    sports: "#22C55E", // Green
    politics: "#3B82F6", // Blue
    entertainment: "#A855F7", // Purple
    crypto: "#F59E0B", // Amber
    general: "#6B7280", // Gray
  }
  return colors[category.toLowerCase()] || colors.general
}

/**
 * Format date as "Dec 12, 2025"
 */
export function formatDate(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date
  return d.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  })
}

/**
 * Format time as "2:30 PM"
 */
export function formatTime(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date
  return d.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  })
}

/**
 * Get status badge color based on status string
 */
export function getStatusBadgeColor(status: string): string {
  const colors: Record<string, string> = {
    // Transaction statuses
    completed: "#22C55E",
    pending: "#F59E0B",
    failed: "#EF4444",
    cancelled: "#6B7280",
    // Event statuses
    active: "#22C55E",
    resolved: "#3B82F6",
    // Challenge statuses
    open: "#FF6B35",
    accepted: "#22C55E",
    expired: "#6B7280",
    // Generic
    win: "#22C55E",
    loss: "#EF4444",
  }
  return colors[status.toLowerCase()] || "#6B7280"
}

/**
 * Calculate percentage for vote distribution
 */
export function calculateVotePercentage(yesVotes: number, noVotes: number): { yes: number; no: number } {
  const total = yesVotes + noVotes
  if (total === 0) return { yes: 50, no: 50 }
  return {
    yes: Math.round((yesVotes / total) * 100),
    no: Math.round((noVotes / total) * 100),
  }
}

/**
 * Format large numbers with K/M suffix
 */
export function formatNumber(num: number): string {
  if (num >= 1_000_000) {
    return `${(num / 1_000_000).toFixed(1).replace(/\.0$/, "")}M`
  }
  if (num >= 1_000) {
    return `${(num / 1_000).toFixed(1).replace(/\.0$/, "")}K`
  }
  return num.toLocaleString()
}

/**
 * Get win rate as percentage string
 */
export function formatWinRate(winRate: number): string {
  return `${Math.round(winRate * 100)}%`
}
