// ==========================================
// BANTAH - Telegram SDK Utilities
// ==========================================

import type { TelegramUser } from "@/types"

// Telegram WebApp window type
declare global {
  interface Window {
    Telegram?: {
      WebApp?: {
        initData: string
        initDataUnsafe: {
          user?: {
            id: number
            first_name: string
            last_name?: string
            username?: string
            photo_url?: string
            is_premium?: boolean
          }
          auth_date: number
          hash: string
        }
        ready: () => void
        expand: () => void
        close: () => void
        MainButton: {
          text: string
          color: string
          textColor: string
          isVisible: boolean
          isActive: boolean
          show: () => void
          hide: () => void
          enable: () => void
          disable: () => void
          onClick: (callback: () => void) => void
          offClick: (callback: () => void) => void
        }
        BackButton: {
          isVisible: boolean
          show: () => void
          hide: () => void
          onClick: (callback: () => void) => void
          offClick: (callback: () => void) => void
        }
        HapticFeedback: {
          impactOccurred: (style: "light" | "medium" | "heavy" | "rigid" | "soft") => void
          notificationOccurred: (type: "error" | "success" | "warning") => void
          selectionChanged: () => void
        }
        themeParams: {
          bg_color?: string
          text_color?: string
          hint_color?: string
          link_color?: string
          button_color?: string
          button_text_color?: string
          secondary_bg_color?: string
        }
        colorScheme: "light" | "dark"
        viewportHeight: number
        viewportStableHeight: number
        isExpanded: boolean
        platform: string
        version: string
      }
    }
  }
}

/**
 * Check if running inside Telegram WebApp
 */
export function isTelegramWebApp(): boolean {
  if (typeof window === "undefined") return false
  return Boolean(window.Telegram?.WebApp?.initData)
}

/**
 * Get Telegram initData string for authentication
 */
export function getTelegramInitData(): string | null {
  if (typeof window === "undefined") return null
  return window.Telegram?.WebApp?.initData || null
}

/**
 * Extract user data from Telegram initData
 */
export function extractTelegramUser(initData?: string): TelegramUser | null {
  // Try from window.Telegram.WebApp.initDataUnsafe first
  if (typeof window !== "undefined" && window.Telegram?.WebApp?.initDataUnsafe?.user) {
    const user = window.Telegram.WebApp.initDataUnsafe.user
    return {
      id: user.id,
      firstName: user.first_name,
      lastName: user.last_name || null,
      username: user.username || null,
      photoUrl: user.photo_url || null,
      isPremium: user.is_premium || false,
    }
  }

  // Parse from initData string if provided
  if (initData) {
    try {
      const params = new URLSearchParams(initData)
      const userParam = params.get("user")
      if (userParam) {
        const userData = JSON.parse(decodeURIComponent(userParam))
        return {
          id: userData.id,
          firstName: userData.first_name,
          lastName: userData.last_name || null,
          username: userData.username || null,
          photoUrl: userData.photo_url || null,
          isPremium: userData.is_premium || false,
        }
      }
    } catch {
      console.error("Failed to parse Telegram initData")
    }
  }

  return null
}

/**
 * Initialize Telegram WebApp (call on app mount)
 */
export function initTelegramWebApp(): void {
  if (typeof window === "undefined") return

  const webApp = window.Telegram?.WebApp
  if (webApp) {
    webApp.ready()
    webApp.expand()
  }
}

/**
 * Trigger haptic feedback
 */
export function hapticFeedback(type: "success" | "error" | "warning" | "light" | "medium" | "heavy"): void {
  if (typeof window === "undefined") return

  const haptic = window.Telegram?.WebApp?.HapticFeedback
  if (!haptic) return

  if (type === "success" || type === "error" || type === "warning") {
    haptic.notificationOccurred(type)
  } else {
    haptic.impactOccurred(type)
  }
}

/**
 * Get Telegram color scheme
 */
export function getTelegramColorScheme(): "light" | "dark" {
  if (typeof window === "undefined") return "dark"
  return window.Telegram?.WebApp?.colorScheme || "dark"
}

/**
 * Close the Telegram Mini App
 */
export function closeTelegramApp(): void {
  if (typeof window === "undefined") return
  window.Telegram?.WebApp?.close()
}

/**
 * Show Telegram Main Button
 */
export function showMainButton(text: string, onClick: () => void): void {
  if (typeof window === "undefined") return

  const mainButton = window.Telegram?.WebApp?.MainButton
  if (!mainButton) return

  mainButton.text = text
  mainButton.onClick(onClick)
  mainButton.show()
}

/**
 * Hide Telegram Main Button
 */
export function hideMainButton(): void {
  if (typeof window === "undefined") return
  window.Telegram?.WebApp?.MainButton?.hide()
}

/**
 * Show Telegram Back Button
 */
export function showBackButton(onClick: () => void): void {
  if (typeof window === "undefined") return

  const backButton = window.Telegram?.WebApp?.BackButton
  if (!backButton) return

  backButton.onClick(onClick)
  backButton.show()
}

/**
 * Hide Telegram Back Button
 */
export function hideBackButton(): void {
  if (typeof window === "undefined") return
  window.Telegram?.WebApp?.BackButton?.hide()
}
