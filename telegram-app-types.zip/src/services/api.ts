// ==========================================
// BANTAH - API Client Service
// ==========================================

import axios, { type AxiosInstance, type AxiosError, type InternalAxiosRequestConfig } from "axios"
import type {
  AuthResponse,
  WalletData,
  EventData,
  ChallengeData,
  LeaderboardEntry,
  UserProfile,
  AchievementData,
} from "../types"

// ==========================================
// Custom Error Class
// ==========================================

export class ApiError extends Error {
  status: number

  constructor(message: string, status = 500) {
    super(message)
    this.name = "ApiError"
    this.status = status
  }
}

// ==========================================
// Axios Instance Setup
// ==========================================

const BASE_URL =
  process.env.NEXT_PUBLIC_API_URL ||
  process.env.VITE_API_URL ||
  (typeof window !== "undefined" && (window as any).__ENV__?.VITE_API_URL) ||
  "http://localhost:5000"

export const apiClient: AxiosInstance = axios.create({
  baseURL: BASE_URL,
  timeout: 10000,
  withCredentials: false,
  headers: {
    "Content-Type": "application/json",
  },
})

// ==========================================
// Request Interceptor
// ==========================================

apiClient.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    // Get Telegram initData from localStorage
    const initData = typeof window !== "undefined" ? localStorage.getItem("telegramInitData") : null

    if (initData) {
      config.headers["X-Telegram-Init-Data"] = initData
    }

    if (process.env.NODE_ENV === "development") {
      console.log(`[API] ${config.method?.toUpperCase()} ${config.url}`, config.data || "")
    }

    return config
  },
  (error) => {
    return Promise.reject(error)
  },
)

// ==========================================
// Response Interceptor
// ==========================================

apiClient.interceptors.response.use(
  (response) => {
    return response
  },
  (error: AxiosError<{ message?: string; error?: string }>) => {
    // Handle network errors
    if (!error.response) {
      if (error.code === "ECONNABORTED") {
        throw new ApiError("Request timeout. Please try again.", 408)
      }
      throw new ApiError("Network error. Please check your connection.", 0)
    }

    const { status, data } = error.response
    const message = data?.message || data?.error || "An unexpected error occurred"

    // Handle specific status codes
    switch (status) {
      case 401:
        // Clear stored auth data and redirect to login
        localStorage.removeItem("telegramInitData")
        localStorage.removeItem("authToken")
        // Optionally trigger a redirect or auth state update
        if (typeof window !== "undefined") {
          window.dispatchEvent(new CustomEvent("auth:unauthorized"))
        }
        throw new ApiError("Session expired. Please login again.", 401)

      case 403:
        throw new ApiError("You do not have permission to perform this action.", 403)

      case 404:
        throw new ApiError("Resource not found.", 404)

      case 422:
        throw new ApiError(message || "Invalid data provided.", 422)

      case 429:
        throw new ApiError("Too many requests. Please slow down.", 429)

      case 500:
      case 502:
      case 503:
        throw new ApiError("Server error. Please try again later.", status)

      default:
        throw new ApiError(message, status)
    }
  },
)

// ==========================================
// API Functions
// ==========================================

// Auth
export async function authenticateUser(initData: string): Promise<AuthResponse> {
  const { data } = await apiClient.post<AuthResponse>("/auth/telegram", { initData })
  return data
}

// Wallet
export async function getWallet(): Promise<WalletData> {
  const { data } = await apiClient.get<WalletData>("/wallet")
  return data
}

// Events
export async function getEvents(limit = 20, offset = 0): Promise<{ events: EventData[]; total: number }> {
  const { data } = await apiClient.get<{ events: EventData[]; total: number }>("/events", {
    params: { limit, offset },
  })
  return data
}

export async function getEventDetails(eventId: string): Promise<EventData> {
  const { data } = await apiClient.get<EventData>(`/events/${eventId}`)
  return data
}

export async function joinEvent(
  eventId: string,
  prediction: boolean,
  amount: number,
): Promise<{ success: boolean; message: string }> {
  const { data } = await apiClient.post<{ success: boolean; message: string }>(`/events/${eventId}/join`, {
    prediction,
    amount,
  })
  return data
}

// Challenges
export async function getChallenges(type?: "created" | "accepted"): Promise<ChallengeData[]> {
  const { data } = await apiClient.get<ChallengeData[]>("/challenges", {
    params: type ? { type } : undefined,
  })
  return data
}

export async function createChallenge(
  title: string,
  description: string,
  wagerAmount: number,
  deadline: string,
): Promise<ChallengeData> {
  const { data } = await apiClient.post<ChallengeData>("/challenges", {
    title,
    description,
    wagerAmount,
    deadline,
  })
  return data
}

export async function acceptChallenge(challengeId: string): Promise<{ success: boolean }> {
  const { data } = await apiClient.post<{ success: boolean }>(`/challenges/${challengeId}/accept`)
  return data
}

// Leaderboard
export async function getLeaderboard(limit = 50): Promise<LeaderboardEntry[]> {
  const { data } = await apiClient.get<LeaderboardEntry[]>("/leaderboard", {
    params: { limit },
  })
  return data
}

// User Profile
export async function getUserProfile(): Promise<UserProfile> {
  const { data } = await apiClient.get<UserProfile>("/user/profile")
  return data
}

// Achievements
export async function getAchievements(): Promise<AchievementData[]> {
  const { data } = await apiClient.get<AchievementData[]>("/user/achievements")
  return data
}

// User Stats
export async function getUserStats(): Promise<{
  level: number
  xp: number
  totalWinnings: number
  winRate: number
}> {
  const { data } = await apiClient.get<{
    level: number
    xp: number
    totalWinnings: number
    winRate: number
  }>("/user/stats")
  return data
}
