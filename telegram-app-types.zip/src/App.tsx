"use client"

// ==========================================
// BANTAH - Main App Component
// ==========================================

import { useState, useEffect } from "react"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { useAuth } from "./hooks/useAuth"
import { useTelegram, useWebApp, useDeepLink } from "./hooks/useTelegram"
import { Layout } from "./components/Layout"

// Pages
import { Home } from "./pages/Home"
import { Wallet } from "./pages/Wallet"
import { Events } from "./pages/Events"
import { Challenges } from "./pages/Challenges"
import { Profile } from "./pages/Profile"
import { Leaderboard } from "./pages/Leaderboard"

// ==========================================
// Query Client Setup
// ==========================================

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      gcTime: 10 * 60 * 1000, // 10 minutes (formerly cacheTime)
      retry: 2,
      refetchOnWindowFocus: false,
    },
    mutations: {
      retry: 1,
    },
  },
})

// ==========================================
// Loading Screen
// ==========================================

function LoadingScreen() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-[#0F1419]">
      <div className="mb-6 text-4xl font-bold text-[#FF6B35]">BANTAH</div>
      <div className="mb-4 h-10 w-10 animate-spin rounded-full border-4 border-[#1A1F2E] border-t-[#FF6B35]" />
      <p className="text-gray-400">Initializing app...</p>
    </div>
  )
}

// ==========================================
// Error Screen
// ==========================================

interface ErrorScreenProps {
  message: string
  onRetry?: () => void
}

function ErrorScreen({ message, onRetry }: ErrorScreenProps) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-[#0F1419] p-4">
      <div className="mb-6 text-4xl font-bold text-[#FF6B35]">BANTAH</div>
      <div className="rounded-xl bg-[#1A1F2E] p-6 text-center">
        <p className="mb-4 text-white">{message}</p>
        {onRetry && (
          <button
            onClick={onRetry}
            className="rounded-lg bg-[#FF6B35] px-6 py-2 font-medium text-white transition-colors hover:bg-[#e55a2a]"
          >
            Retry
          </button>
        )}
      </div>
    </div>
  )
}

// ==========================================
// Not Found Page
// ==========================================

function NotFound({ onGoHome }: { onGoHome: () => void }) {
  return (
    <div className="flex h-full flex-col items-center justify-center p-4">
      <p className="mb-2 text-6xl">🔍</p>
      <h1 className="mb-2 text-2xl font-bold text-white">Page Not Found</h1>
      <p className="mb-6 text-gray-400">The page you're looking for doesn't exist.</p>
      <button
        onClick={onGoHome}
        className="rounded-lg bg-[#FF6B35] px-6 py-2 font-medium text-white transition-colors hover:bg-[#e55a2a]"
      >
        Go Home
      </button>
    </div>
  )
}

// ==========================================
// App Router
// ==========================================

type Route = "/" | "/wallet" | "/events" | "/challenges" | "/profile" | "/leaderboard" | "/404"

interface AppRouterProps {
  route: Route
  onNavigate: (route: Route) => void
}

function AppRouter({ route, onNavigate }: AppRouterProps) {
  const renderPage = () => {
    switch (route) {
      case "/":
        return <Home />
      case "/wallet":
        return <Wallet />
      case "/events":
        return <Events />
      case "/challenges":
        return <Challenges />
      case "/profile":
        return <Profile />
      case "/leaderboard":
        return <Leaderboard />
      case "/404":
      default:
        return <NotFound onGoHome={() => onNavigate("/")} />
    }
  }

  return <Layout>{renderPage()}</Layout>
}

// ==========================================
// Main App Content
// ==========================================

function AppContent() {
  const { isLoading, error, retry, isAuthenticated } = useAuth()
  const { startParam } = useTelegram()
  const { webApp, haptic, showBackButton, hideBackButton } = useWebApp()
  const deepLink = useDeepLink(startParam)

  const [currentRoute, setCurrentRoute] = useState<Route>("/wallet")
  const [routeHistory, setRouteHistory] = useState<Route[]>(["/wallet"])

  // Handle deep links on mount
  useEffect(() => {
    if (deepLink.action) {
      switch (deepLink.action) {
        case "event":
          setCurrentRoute("/events")
          break
        case "challenge":
          setCurrentRoute("/challenges")
          break
        case "leaderboard":
          setCurrentRoute("/leaderboard")
          break
        case "profile":
          setCurrentRoute("/profile")
          break
        case "wallet":
          setCurrentRoute("/wallet")
          break
      }
    }
  }, [deepLink.action])

  // Handle navigation events from components
  useEffect(() => {
    const handleNavigate = (e: CustomEvent<string>) => {
      const route = e.detail as Route
      navigate(route)
    }

    window.addEventListener("navigate", handleNavigate as EventListener)
    return () => window.removeEventListener("navigate", handleNavigate as EventListener)
  }, [])

  // Setup Telegram WebApp
  useEffect(() => {
    if (webApp) {
      // Set background color
      document.body.style.backgroundColor = "#0F1419"
    }
  }, [webApp])

  // Handle back button
  useEffect(() => {
    if (routeHistory.length > 1) {
      showBackButton(() => {
        haptic("light")
        goBack()
      })
    } else {
      hideBackButton()
    }
  }, [routeHistory, showBackButton, hideBackButton, haptic])

  const navigate = (route: Route) => {
    haptic("light")
    setCurrentRoute(route)
    setRouteHistory((prev) => [...prev, route])
  }

  const goBack = () => {
    if (routeHistory.length > 1) {
      const newHistory = routeHistory.slice(0, -1)
      setRouteHistory(newHistory)
      setCurrentRoute(newHistory[newHistory.length - 1])
    }
  }

  // Loading state
  if (isLoading) {
    return <LoadingScreen />
  }

  // Error state
  if (error && !isAuthenticated) {
    return <ErrorScreen message={error.message} onRetry={retry} />
  }

  return <AppRouter route={currentRoute} onNavigate={navigate} />
}

// ==========================================
// App Component with Providers
// ==========================================

export function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AppContent />
    </QueryClientProvider>
  )
}

export default App
