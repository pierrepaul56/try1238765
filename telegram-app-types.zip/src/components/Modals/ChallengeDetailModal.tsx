"use client"

import { useMutation, useQueryClient } from "@tanstack/react-query"
import { X, User, Clock, Trophy, CheckCircle, Circle, Swords } from "lucide-react"
import type { ChallengeData } from "../../types"
import { formatBalance, getTimeRemaining, formatDate, getStatusBadgeColor } from "../../utils/format"
import { hapticFeedback } from "../../utils/telegram"
import { acceptChallenge } from "../../services/api"

interface ChallengeDetailModalProps {
  challenge: ChallengeData
  onClose: () => void
  currentUserId?: number
}

const statusLabels: Record<ChallengeData["status"], string> = {
  open: "Pending",
  accepted: "Matched",
  resolved: "Completed",
  cancelled: "Cancelled",
  expired: "Expired",
}

export function ChallengeDetailModal({ challenge, onClose, currentUserId }: ChallengeDetailModalProps) {
  const queryClient = useQueryClient()
  const statusColor = getStatusBadgeColor(challenge.status === "open" ? "pending" : challenge.status)
  const timeRemaining = getTimeRemaining(challenge.deadline)
  const isExpired = timeRemaining === "Expired"
  const isCreator = currentUserId === challenge.creator.id
  const canAccept = challenge.status === "open" && !isCreator && !isExpired

  const mutation = useMutation({
    mutationFn: () => acceptChallenge(challenge.id),
    onSuccess: () => {
      hapticFeedback("success")
      queryClient.invalidateQueries({ queryKey: ["challenges"] })
      queryClient.invalidateQueries({ queryKey: ["wallet"] })
      onClose()
    },
    onError: () => {
      hapticFeedback("error")
    },
  })

  const handleAccept = () => {
    hapticFeedback("medium")
    mutation.mutate()
  }

  // Timeline steps
  const steps = [
    { label: "Created", completed: true, date: challenge.createdAt },
    { label: "Matched", completed: challenge.status !== "open" && challenge.status !== "cancelled" },
    { label: "Completed", completed: challenge.status === "resolved" },
  ]

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm">
      <div className="max-h-[90vh] w-full overflow-y-auto rounded-t-3xl bg-[#0F1419] pb-safe">
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-gray-800 bg-[#0F1419] p-4">
          <h2 className="text-lg font-semibold text-white">Challenge Details</h2>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-gray-800 text-gray-400 hover:bg-gray-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-6 p-4">
          {/* Status Badge */}
          <div className="flex justify-center">
            <span
              className="rounded-full px-4 py-2 text-sm font-medium"
              style={{ backgroundColor: `${statusColor}20`, color: statusColor }}
            >
              {statusLabels[challenge.status]}
            </span>
          </div>

          {/* Title and Description */}
          <div className="text-center">
            <h3 className="text-xl font-bold text-white">{challenge.title}</h3>
            <p className="mt-2 text-gray-400">{challenge.description}</p>
          </div>

          {/* Wager Amount */}
          <div className="rounded-xl bg-[#1A1F26] p-6 text-center">
            <Swords className="mx-auto mb-2 h-8 w-8 text-[#FF6B35]" />
            <span className="text-sm text-gray-400">Wager Amount</span>
            <p className="text-3xl font-bold text-[#FF6B35]">{formatBalance(challenge.wagerAmount)}</p>
          </div>

          {/* Participants */}
          <div className="grid grid-cols-2 gap-4">
            {/* Creator */}
            <div className="rounded-xl bg-[#1A1F26] p-4 text-center">
              <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-[#FF6B35]/20">
                <User className="h-6 w-6 text-[#FF6B35]" />
              </div>
              <p className="text-xs text-gray-400">Creator</p>
              <p className="font-medium text-white">@{challenge.creator.username || challenge.creator.firstName}</p>
              {isCreator && <span className="text-xs text-[#FF6B35]">(You)</span>}
            </div>

            {/* Acceptor */}
            <div className="rounded-xl bg-[#1A1F26] p-4 text-center">
              <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-blue-500/20">
                <User className="h-6 w-6 text-blue-400" />
              </div>
              <p className="text-xs text-gray-400">Opponent</p>
              {challenge.acceptor ? (
                <p className="font-medium text-white">@{challenge.acceptor.username || challenge.acceptor.firstName}</p>
              ) : (
                <p className="text-gray-500">Looking for opponent...</p>
              )}
            </div>
          </div>

          {/* Timeline */}
          <div className="rounded-xl bg-[#1A1F26] p-4">
            <h4 className="mb-4 font-medium text-white">Status Timeline</h4>
            <div className="flex items-center justify-between">
              {steps.map((step, index) => (
                <div key={step.label} className="flex flex-1 items-center">
                  <div className="flex flex-col items-center">
                    {step.completed ? (
                      <CheckCircle className="h-6 w-6 text-green-500" />
                    ) : (
                      <Circle className="h-6 w-6 text-gray-600" />
                    )}
                    <span className={`mt-1 text-xs ${step.completed ? "text-green-500" : "text-gray-500"}`}>
                      {step.label}
                    </span>
                  </div>
                  {index < steps.length - 1 && (
                    <div className={`mx-2 h-0.5 flex-1 ${step.completed ? "bg-green-500" : "bg-gray-700"}`} />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Winner (if resolved) */}
          {challenge.status === "resolved" && challenge.winnerId && (
            <div className="rounded-xl bg-green-500/20 p-4 text-center">
              <Trophy className="mx-auto mb-2 h-8 w-8 text-yellow-400" />
              <p className="font-medium text-white">
                Winner:{" "}
                {challenge.winnerId === challenge.creator.id
                  ? challenge.creator.username || challenge.creator.firstName
                  : challenge.acceptor?.username || challenge.acceptor?.firstName}
              </p>
            </div>
          )}

          {/* Deadline */}
          <div className="flex items-center justify-center gap-2 text-sm text-gray-400">
            <Clock className={`h-4 w-4 ${isExpired ? "text-red-400" : ""}`} />
            <span className={isExpired ? "text-red-400" : ""}>
              {isExpired ? "Expired" : `Deadline: ${formatDate(challenge.deadline)}`}
            </span>
          </div>

          {/* Accept Button */}
          {canAccept && (
            <button
              onClick={handleAccept}
              disabled={mutation.isPending}
              className="w-full rounded-xl bg-[#FF6B35] py-4 text-lg font-semibold text-white transition-all hover:bg-[#FF6B35]/90 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {mutation.isPending ? "Accepting..." : `Accept Challenge (${formatBalance(challenge.wagerAmount)})`}
            </button>
          )}

          {isCreator && challenge.status === "open" && (
            <div className="rounded-xl bg-yellow-500/20 p-4 text-center">
              <p className="text-sm text-yellow-400">Waiting for someone to accept your challenge...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
