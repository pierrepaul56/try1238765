"use client"

import { useState } from "react"
import { useMutation, useQueryClient } from "@tanstack/react-query"
import { X, Users, Clock, Wallet } from "lucide-react"
import type { EventData } from "../../types"
import {
  formatBalance,
  getTimeRemaining,
  getCategoryColor,
  calculateVotePercentage,
  formatDate,
} from "../../utils/format"
import { hapticFeedback } from "../../utils/telegram"
import { joinEvent } from "../../services/api"

interface EventDetailModalProps {
  event: EventData
  onClose: () => void
  userBalance?: number
}

export function EventDetailModal({ event, onClose, userBalance = 0 }: EventDetailModalProps) {
  const [prediction, setPrediction] = useState<boolean | null>(null)
  const [amount, setAmount] = useState(event.entryFee.toString())
  const queryClient = useQueryClient()

  const { yes: yesPercent, no: noPercent } = calculateVotePercentage(event.yesVotes, event.noVotes)
  const categoryColor = getCategoryColor(event.category)
  const timeRemaining = getTimeRemaining(event.deadline)
  const isExpired = timeRemaining === "Expired"
  const enteredAmount = Number.parseFloat(amount) || 0
  const hasInsufficientFunds = enteredAmount > userBalance
  const canSubmit = prediction !== null && enteredAmount >= event.entryFee && !hasInsufficientFunds && !isExpired

  const mutation = useMutation({
    mutationFn: () => joinEvent(event.id, prediction!, enteredAmount),
    onSuccess: () => {
      hapticFeedback("success")
      queryClient.invalidateQueries({ queryKey: ["events"] })
      queryClient.invalidateQueries({ queryKey: ["wallet"] })
      onClose()
    },
    onError: () => {
      hapticFeedback("error")
    },
  })

  const handlePredictionSelect = (value: boolean) => {
    hapticFeedback("light")
    setPrediction(value)
  }

  const handleSubmit = () => {
    if (!canSubmit) return
    hapticFeedback("medium")
    mutation.mutate()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm">
      <div className="max-h-[90vh] w-full overflow-y-auto rounded-t-3xl bg-[#0F1419] pb-safe">
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-gray-800 bg-[#0F1419] p-4">
          <h2 className="text-lg font-semibold text-white">Event Details</h2>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-gray-800 text-gray-400 hover:bg-gray-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-6 p-4">
          {/* Title and Category */}
          <div>
            <div className="mb-2 flex items-start gap-2">
              <span
                className="shrink-0 rounded-full px-2 py-1 text-xs font-medium capitalize"
                style={{ backgroundColor: `${categoryColor}20`, color: categoryColor }}
              >
                {event.category}
              </span>
            </div>
            <h3 className="text-xl font-bold text-white">{event.title}</h3>
            <p className="mt-2 text-gray-400">{event.description}</p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-xl bg-[#1A1F26] p-3 text-center">
              <Wallet className="mx-auto mb-1 h-5 w-5 text-[#FF6B35]" />
              <p className="text-xs text-gray-400">Total Pool</p>
              <p className="font-semibold text-white">{formatBalance(event.totalPool)}</p>
            </div>
            <div className="rounded-xl bg-[#1A1F26] p-3 text-center">
              <Users className="mx-auto mb-1 h-5 w-5 text-blue-400" />
              <p className="text-xs text-gray-400">Participants</p>
              <p className="font-semibold text-white">{event.yesVotes + event.noVotes}</p>
            </div>
            <div className="rounded-xl bg-[#1A1F26] p-3 text-center">
              <Clock className={`mx-auto mb-1 h-5 w-5 ${isExpired ? "text-red-400" : "text-green-400"}`} />
              <p className="text-xs text-gray-400">Deadline</p>
              <p className={`font-semibold ${isExpired ? "text-red-400" : "text-white"}`}>
                {formatDate(event.deadline)}
              </p>
            </div>
          </div>

          {/* Vote Distribution */}
          <div className="rounded-xl bg-[#1A1F26] p-4">
            <h4 className="mb-3 font-medium text-white">Current Predictions</h4>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <span className="w-10 text-sm font-medium text-green-500">YES</span>
                <div className="h-3 flex-1 overflow-hidden rounded-full bg-gray-700">
                  <div
                    className="h-full rounded-full bg-green-500 transition-all duration-500"
                    style={{ width: `${yesPercent}%` }}
                  />
                </div>
                <span className="w-12 text-right text-sm text-gray-300">{yesPercent}%</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="w-10 text-sm font-medium text-red-500">NO</span>
                <div className="h-3 flex-1 overflow-hidden rounded-full bg-gray-700">
                  <div
                    className="h-full rounded-full bg-red-500 transition-all duration-500"
                    style={{ width: `${noPercent}%` }}
                  />
                </div>
                <span className="w-12 text-right text-sm text-gray-300">{noPercent}%</span>
              </div>
            </div>
          </div>

          {/* Prediction Selector */}
          {!isExpired && (
            <>
              <div>
                <h4 className="mb-3 font-medium text-white">Your Prediction</h4>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => handlePredictionSelect(true)}
                    className={`rounded-xl p-4 text-lg font-bold transition-all ${
                      prediction === true ? "bg-green-500 text-white" : "bg-[#1A1F26] text-gray-400 hover:bg-[#1E252D]"
                    }`}
                  >
                    YES
                  </button>
                  <button
                    onClick={() => handlePredictionSelect(false)}
                    className={`rounded-xl p-4 text-lg font-bold transition-all ${
                      prediction === false ? "bg-red-500 text-white" : "bg-[#1A1F26] text-gray-400 hover:bg-[#1E252D]"
                    }`}
                  >
                    NO
                  </button>
                </div>
              </div>

              {/* Amount Input */}
              <div>
                <div className="mb-2 flex items-center justify-between">
                  <h4 className="font-medium text-white">Entry Amount</h4>
                  <span className="text-sm text-gray-400">Min: {formatBalance(event.entryFee)}</span>
                </div>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-lg text-gray-400">₦</span>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    min={event.entryFee}
                    className="w-full rounded-xl bg-[#1A1F26] py-4 pl-10 pr-4 text-lg text-white outline-none ring-2 ring-transparent focus:ring-[#FF6B35]"
                    placeholder={event.entryFee.toString()}
                  />
                </div>
                {hasInsufficientFunds && (
                  <p className="mt-2 text-sm text-red-400">
                    Insufficient balance. You have {formatBalance(userBalance)}
                  </p>
                )}
              </div>

              {/* Submit Button */}
              <button
                onClick={handleSubmit}
                disabled={!canSubmit || mutation.isPending}
                className="w-full rounded-xl bg-[#FF6B35] py-4 text-lg font-semibold text-white transition-all hover:bg-[#FF6B35]/90 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {mutation.isPending ? "Placing Prediction..." : "Place Prediction"}
              </button>
            </>
          )}

          {isExpired && (
            <div className="rounded-xl bg-red-500/20 p-4 text-center">
              <p className="font-medium text-red-400">This event has ended</p>
              <p className="text-sm text-gray-400">Predictions are no longer accepted</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
