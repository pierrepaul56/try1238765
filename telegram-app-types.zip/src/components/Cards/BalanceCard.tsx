"use client"

import { useState } from "react"
import { RefreshCw, Coins } from "lucide-react"
import { formatBalance, formatCoinBalance } from "../../utils/format"
import { hapticFeedback } from "../../utils/telegram"

interface BalanceCardProps {
  balance: number
  coins: number
  lastUpdated: string
  onRefresh: () => void
  isRefreshing?: boolean
}

export function BalanceCard({ balance, coins, lastUpdated, onRefresh, isRefreshing = false }: BalanceCardProps) {
  const [showCoins, setShowCoins] = useState(false)

  const handleToggle = () => {
    hapticFeedback("light")
    setShowCoins(!showCoins)
  }

  const handleRefresh = () => {
    hapticFeedback("medium")
    onRefresh()
  }

  const formattedDate = new Date(lastUpdated).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  })

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#FF6B35] to-[#1A1F26] p-6">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-white/20" />
        <div className="absolute -bottom-4 -left-4 h-24 w-24 rounded-full bg-white/10" />
      </div>

      <div className="relative">
        {/* Header */}
        <div className="mb-4 flex items-center justify-between">
          <span className="text-sm font-medium text-white/70">{showCoins ? "Coins Balance" : "Available Balance"}</span>
          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-white/10 transition-colors hover:bg-white/20 disabled:opacity-50"
          >
            <RefreshCw className={`h-4 w-4 text-white ${isRefreshing ? "animate-spin" : ""}`} />
          </button>
        </div>

        {/* Balance display */}
        <div className="mb-6">
          {showCoins ? (
            <div className="flex items-center gap-2">
              <Coins className="h-8 w-8 text-yellow-400" />
              <span className="text-4xl font-bold text-white">{formatCoinBalance(coins)}</span>
            </div>
          ) : (
            <span className="text-4xl font-bold text-white">{formatBalance(balance)}</span>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between">
          <span className="text-xs text-white/50">Last updated: {formattedDate}</span>
          <button
            onClick={handleToggle}
            className="rounded-full bg-white/10 px-3 py-1 text-xs font-medium text-white transition-colors hover:bg-white/20"
          >
            {showCoins ? "Show NGN" : "Show Coins"}
          </button>
        </div>
      </div>
    </div>
  )
}
