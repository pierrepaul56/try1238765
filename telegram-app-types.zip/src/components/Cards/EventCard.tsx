"use client"

import { Users, Clock } from "lucide-react"
import type { EventData } from "../../types"
import { formatBalance, getTimeRemaining, getCategoryColor, calculateVotePercentage } from "../../utils/format"
import { hapticFeedback } from "../../utils/telegram"

interface EventCardProps {
  event: EventData
  onClick: () => void
}

export function EventCard({ event, onClick }: EventCardProps) {
  const { yes: yesPercent, no: noPercent } = calculateVotePercentage(event.yesVotes, event.noVotes)
  const categoryColor = getCategoryColor(event.category)
  const timeRemaining = getTimeRemaining(event.deadline)
  const totalParticipants = event.yesVotes + event.noVotes
  const isExpired = timeRemaining === "Expired"

  const handleClick = () => {
    hapticFeedback("light")
    onClick()
  }

  return (
    <div
      onClick={handleClick}
      className="cursor-pointer rounded-xl bg-[#1A1F26] p-4 transition-all hover:scale-[1.02] hover:bg-[#1E252D] active:scale-[0.98]"
    >
      {/* Header */}
      <div className="mb-3 flex items-start justify-between gap-2">
        <h3 className="line-clamp-2 flex-1 font-semibold text-white">{event.title}</h3>
        <span
          className="shrink-0 rounded-full px-2 py-1 text-xs font-medium capitalize"
          style={{ backgroundColor: `${categoryColor}20`, color: categoryColor }}
        >
          {event.category}
        </span>
      </div>

      {/* Pool info */}
      <div className="mb-3 flex items-center justify-between text-sm">
        <span className="text-gray-400">
          Entry: <span className="font-medium text-white">{formatBalance(event.entryFee)}</span>
        </span>
        <span className="text-gray-400">
          Pool: <span className="font-medium text-[#FF6B35]">{formatBalance(event.totalPool)}</span>
        </span>
      </div>

      {/* Vote distribution bars */}
      <div className="mb-3 space-y-2">
        <div className="flex items-center gap-2">
          <span className="w-8 text-xs font-medium text-green-500">YES</span>
          <div className="h-2 flex-1 overflow-hidden rounded-full bg-gray-700">
            <div
              className="h-full rounded-full bg-green-500 transition-all duration-300"
              style={{ width: `${yesPercent}%` }}
            />
          </div>
          <span className="w-10 text-right text-xs text-gray-400">{yesPercent}%</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-8 text-xs font-medium text-red-500">NO</span>
          <div className="h-2 flex-1 overflow-hidden rounded-full bg-gray-700">
            <div
              className="h-full rounded-full bg-red-500 transition-all duration-300"
              style={{ width: `${noPercent}%` }}
            />
          </div>
          <span className="w-10 text-right text-xs text-gray-400">{noPercent}%</span>
        </div>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between text-xs text-gray-400">
        <div className="flex items-center gap-1">
          <Users className="h-3.5 w-3.5" />
          <span>{totalParticipants} participants</span>
        </div>
        <div className={`flex items-center gap-1 ${isExpired ? "text-red-400" : ""}`}>
          <Clock className="h-3.5 w-3.5" />
          <span>{timeRemaining}</span>
        </div>
      </div>
    </div>
  )
}
