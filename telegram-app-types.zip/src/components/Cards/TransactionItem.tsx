"use client"

import { ArrowDownLeft, ArrowUpRight, Trophy, Swords, Gift, Undo2 } from "lucide-react"
import type { TransactionItem as TransactionItemType } from "../../types"
import { formatBalance, formatDate, formatTime, getStatusBadgeColor } from "../../utils/format"

interface TransactionItemProps {
  transaction: TransactionItemType
}

const typeConfig: Record<
  TransactionItemType["type"],
  { icon: typeof ArrowDownLeft; label: string; isIncome: boolean }
> = {
  deposit: { icon: ArrowDownLeft, label: "Deposit", isIncome: true },
  withdrawal: { icon: ArrowUpRight, label: "Withdrawal", isIncome: false },
  wager: { icon: Swords, label: "Entry Fee", isIncome: false },
  win: { icon: Trophy, label: "Win", isIncome: true },
  loss: { icon: Swords, label: "Loss", isIncome: false },
  bonus: { icon: Gift, label: "Bonus", isIncome: true },
  refund: { icon: Undo2, label: "Refund", isIncome: true },
}

export function TransactionItem({ transaction }: TransactionItemProps) {
  const config = typeConfig[transaction.type]
  const Icon = config.icon
  const isIncome = config.isIncome
  const statusColor = getStatusBadgeColor(transaction.status)

  return (
    <div className="flex items-center gap-3 rounded-xl bg-[#1A1F26] p-4 transition-colors hover:bg-[#1E252D]">
      {/* Icon */}
      <div
        className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${
          isIncome ? "bg-green-500/20" : "bg-red-500/20"
        }`}
      >
        <Icon className={`h-5 w-5 ${isIncome ? "text-green-500" : "text-red-500"}`} />
      </div>

      {/* Details */}
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="font-medium text-white">{config.label}</span>
          {transaction.status !== "completed" && (
            <span
              className="rounded-full px-2 py-0.5 text-xs font-medium capitalize"
              style={{ backgroundColor: `${statusColor}20`, color: statusColor }}
            >
              {transaction.status}
            </span>
          )}
        </div>
        <p className="truncate text-sm text-gray-400">{transaction.description}</p>
        <span className="text-xs text-gray-500">
          {formatDate(transaction.timestamp)} at {formatTime(transaction.timestamp)}
        </span>
      </div>

      {/* Amount */}
      <div className={`shrink-0 text-right font-semibold ${isIncome ? "text-green-500" : "text-red-500"}`}>
        {isIncome ? "+" : "-"}
        {formatBalance(Math.abs(transaction.amount))}
      </div>
    </div>
  )
}
