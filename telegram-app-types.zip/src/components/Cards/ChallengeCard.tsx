"use client"

import { Clock, User } from "lucide-react"
import type { ChallengeData } from "../../types"
import { formatBalance, getTimeRemaining, getStatusBadgeColor } from "../../utils/format"
import { hapticFeedback } from "../../utils/telegram"

interface ChallengeCardProps {
  challenge: ChallengeData
  onClick: () => void
}

const statusLabels: Record<ChallengeData["status"], string> = {
  open: "Pending",
  accepted: "Matched",
  resolved: "Completed",
  cancelled: "Cancelled",
  expired: "Expired",
}

export function ChallengeCard({ challenge, onClick }: ChallengeCardProps) {
  const statusColor = getStatusBadgeColor(challenge.status === "open" ? "pending" : challenge.status)
  const timeRemaining = getTimeRemaining(challenge.deadline)
  const creatorName = challenge.creator.username || challenge.creator.firstName

  const handleClick = () => {
    hapticFeedback("light")
    onClick()
  }

  return (
    <div
      onClick={handleClick}
      className="cursor-pointer rounded-xl bg-[#1A1F26] p-4 transition-all hover:scale-[1.02] hover:bg-[#1E252D] active:scale-[0.98]"
    >
      {/* Header */}
      <div className="mb-2 flex items-start justify-between gap-2">
        <h3 className="flex-1 font-semibold text-white">{challenge.title}</h3>
        <span
          className="shrink-0 rounded-full px-2 py-1 text-xs font-medium"
          style={{ backgroundColor: `${statusColor}20`, color: statusColor }}
        >
          {statusLabels[challenge.status]}
        </span>
      </div>

      {/* Description */}
      <p className="mb-3 line-clamp-2 text-sm text-gray-400">{challenge.description}</p>

      {/* Wager Amount */}
      <div className="mb-3 rounded-lg bg-[#0F1419] p-3 text-center">
        <span className="text-xs text-gray-500">Wager Amount</span>
        <p className="text-2xl font-bold text-[#FF6B35]">{formatBalance(challenge.wagerAmount)}</p>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between text-xs text-gray-400">
        <div className="flex items-center gap-1">
          <User className="h-3.5 w-3.5" />
          <span>@{creatorName}</span>
        </div>
        <div className={`flex items-center gap-1 ${timeRemaining === "Expired" ? "text-red-400" : ""}`}>
          <Clock className="h-3.5 w-3.5" />
          <span>{timeRemaining}</span>
        </div>
      </div>
    </div>
  )
}
