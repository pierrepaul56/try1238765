"use client"

// ==========================================
// BANTAH - Main Layout Component
// ==========================================

import React from "react"
import { Navbar } from "./Navbar"
import { BottomNavigation } from "./BottomNavigation"
import { useWebApp } from "../hooks/useTelegram"

// ==========================================
// Types
// ==========================================

interface LayoutProps {
  children: React.ReactNode
  hideNavbar?: boolean
  hideBottomNav?: boolean
}

// ==========================================
// Error Boundary
// ==========================================

interface ErrorBoundaryState {
  hasError: boolean
  error?: Error
}

class ErrorBoundary extends React.Component<
  { children: React.ReactNode; fallback?: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { children: React.ReactNode; fallback?: React.ReactNode }) {
    super(props)
    this.state = { hasError: false }
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error }
  }

  render() {
    if (this.state.hasError) {
      return (
        this.props.fallback || (
          <div className="flex min-h-screen flex-col items-center justify-center bg-[#0F1419] p-4 text-white">
            <div className="rounded-xl bg-[#1A1F2E] p-6 text-center">
              <h2 className="mb-2 text-xl font-bold text-[#FF6B35]">Something went wrong</h2>
              <p className="mb-4 text-sm text-gray-400">Please restart the app</p>
              <button
                onClick={() => window.location.reload()}
                className="rounded-lg bg-[#FF6B35] px-4 py-2 font-medium text-white transition-colors hover:bg-[#e55a2a]"
              >
                Reload
              </button>
            </div>
          </div>
        )
      )
    }

    return this.props.children
  }
}

// ==========================================
// Layout Component
// ==========================================

export function Layout({ children, hideNavbar = false, hideBottomNav = false }: LayoutProps) {
  const { isReady, viewportHeight } = useWebApp()

  return (
    <ErrorBoundary>
      <div
        className="flex min-h-screen flex-col bg-[#0F1419]"
        style={{
          minHeight: viewportHeight > 0 ? `${viewportHeight}px` : "100vh",
          // Telegram safe area CSS variables
          paddingTop: "env(safe-area-inset-top, 0px)",
        }}
      >
        {/* Header */}
        {!hideNavbar && <Navbar />}

        {/* Main Content */}
        <main
          className="flex-1 overflow-y-auto"
          style={{
            paddingBottom: hideBottomNav
              ? "env(safe-area-inset-bottom, 0px)"
              : "calc(72px + env(safe-area-inset-bottom, 0px))",
          }}
        >
          {isReady || typeof window === "undefined" ? (
            children
          ) : (
            <div className="flex h-full items-center justify-center">
              <div className="h-8 w-8 animate-spin rounded-full border-2 border-[#FF6B35] border-t-transparent" />
            </div>
          )}
        </main>

        {/* Bottom Navigation */}
        {!hideBottomNav && <BottomNavigation />}
      </div>
    </ErrorBoundary>
  )
}

export default Layout
