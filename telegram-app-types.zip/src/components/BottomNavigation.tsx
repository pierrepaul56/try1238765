"use client"
import { usePathname, useRouter } from "next/navigation"
import { useWebApp } from "../hooks/useTelegram"

// ==========================================
// Types
// ==========================================

interface NavItem {
  path: string
  label: string
  icon: string
}

interface NavButtonProps {
  item: NavItem
  isActive: boolean
  onClick: () => void
}

// ==========================================
// Navigation Items
// ==========================================

const navItems: NavItem[] = [
  { path: "/wallet", label: "Wallet", icon: "💰" },
  { path: "/events", label: "Events", icon: "🎯" },
  { path: "/challenges", label: "Challenges", icon: "🥊" },
  { path: "/profile", label: "Profile", icon: "👤" },
]

// ==========================================
// NavButton Component
// ==========================================

function NavButton({ item, isActive, onClick }: NavButtonProps) {
  return (
    <button
      onClick={onClick}
      className={`
        flex flex-1 flex-col items-center justify-center gap-0.5 py-2 transition-all duration-200
        ${isActive ? "text-[#FF6B35]" : "text-gray-500 hover:text-gray-400"}
      `}
      aria-label={item.label}
      aria-current={isActive ? "page" : undefined}
    >
      {/* Icon with active background */}
      <div
        className={`
          flex h-8 w-12 items-center justify-center rounded-full transition-all duration-200
          ${isActive ? "bg-[#FF6B35]/15" : "bg-transparent"}
        `}
      >
        <span className="text-xl" role="img" aria-hidden="true">
          {item.icon}
        </span>
      </div>

      {/* Label */}
      <span
        className={`
          text-[10px] font-medium transition-colors duration-200
          ${isActive ? "text-[#FF6B35]" : "text-gray-500"}
        `}
      >
        {item.label}
      </span>
    </button>
  )
}

// ==========================================
// BottomNavigation Component
// ==========================================

export function BottomNavigation() {
  const router = useRouter()
  const pathname = usePathname()
  const { haptic } = useWebApp()

  const handleNavClick = (path: string) => {
    // Trigger haptic feedback
    haptic("light")

    // Navigate to the selected tab
    router.push(path)
  }

  const isActive = (path: string): boolean => {
    if (path === "/wallet" && pathname === "/") return true
    return pathname.startsWith(path)
  }

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-50 border-t border-white/5 bg-[#0F1419]"
      style={{
        paddingBottom: "env(safe-area-inset-bottom, 0px)",
      }}
    >
      <div className="flex h-16 items-center justify-around">
        {navItems.map((item) => (
          <NavButton
            key={item.path}
            item={item}
            isActive={isActive(item.path)}
            onClick={() => handleNavClick(item.path)}
          />
        ))}
      </div>
    </nav>
  )
}

export default BottomNavigation
