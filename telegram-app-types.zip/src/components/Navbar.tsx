"use client"
import { useAuth } from "../hooks/useAuth"
import { formatBalance } from "../utils/format"

// ==========================================
// Types
// ==========================================

interface NavbarProps {
  showBalance?: boolean
}

// ==========================================
// Navbar Component
// ==========================================

export function Navbar({ showBalance = true }: NavbarProps) {
  const { user, isAuthenticated } = useAuth()

  // Mock balance for now - will be replaced with real data from wallet hook
  const balance = 15000

  return (
    <header
      className="sticky top-0 z-50 border-b border-white/5 bg-[#0F1419]"
      style={{
        paddingTop: "env(safe-area-inset-top, 0px)",
      }}
    >
      <div className="flex h-14 items-center justify-between px-4">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <h1 className="text-xl font-bold tracking-tight text-white">BANTAH</h1>
        </div>

        {/* Right Side - Balance & Level */}
        {isAuthenticated && showBalance && (
          <div className="flex items-center gap-2">
            {/* Level Badge */}
            {user && (
              <div className="flex items-center gap-1 rounded-full bg-[#1A1F2E] px-2 py-1">
                <span className="text-xs font-medium text-[#FF6B35]">LVL {user.level || 1}</span>
              </div>
            )}

            {/* Balance Pill */}
            <div className="flex items-center gap-1 rounded-full bg-[#1A1F2E] px-3 py-1.5">
              <span className="text-sm font-semibold text-white">{formatBalance(balance)}</span>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}

export default Navbar
