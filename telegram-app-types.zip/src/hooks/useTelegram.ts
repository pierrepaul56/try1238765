"use client"

// ==========================================
// BANTAH - Telegram Hooks
// ==========================================

import { useState, useEffect, useCallback } from "react"
import type { TelegramUser } from "../types"
import {
  isTelegramWebApp,
  getTelegramInitData,
  extractTelegramUser,
  initTelegramWebApp,
  hapticFeedback,
  showBackButton,
  hideBackButton,
} from "../utils/telegram"

// ==========================================
// Types
// ==========================================

export type LaunchContext = "direct" | "inline_query" | "group" | "supergroup" | "channel"

export interface UseTelegramReturn {
  initData: string | null
  user: TelegramUser | null
  startParam: string | null
  chatId: number | null
  chatType: string | null
  launchContext: LaunchContext
  isLoading: boolean
  error: Error | null
  isGroup: boolean
  isTelegram: boolean
}

export interface UseWebAppReturn {
  webApp: typeof window.Telegram.WebApp | null
  isReady: boolean
  platform: string
  colorScheme: "light" | "dark"
  viewportHeight: number
  expand: () => void
  close: () => void
  haptic: (type: "success" | "error" | "warning" | "light" | "medium" | "heavy") => void
  showBackButton: (onClick: () => void) => void
  hideBackButton: () => void
}

// ==========================================
// useTelegram Hook
// ==========================================

export function useTelegram(): UseTelegramReturn {
  const [initData, setInitData] = useState<string | null>(null)
  const [user, setUser] = useState<TelegramUser | null>(null)
  const [startParam, setStartParam] = useState<string | null>(null)
  const [chatId, setChatId] = useState<number | null>(null)
  const [chatType, setChatType] = useState<string | null>(null)
  const [launchContext, setLaunchContext] = useState<LaunchContext>("direct")
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    try {
      // Initialize Telegram WebApp
      initTelegramWebApp()

      // Get initData
      const data = getTelegramInitData()
      setInitData(data)

      // Extract user
      const telegramUser = extractTelegramUser(data || undefined)
      setUser(telegramUser)

      // Parse initData for additional params
      if (data) {
        const params = new URLSearchParams(data)

        // Extract start_param (deep link parameter)
        const start = params.get("start_param")
        setStartParam(start)

        // Extract chat info if present
        const chatParam = params.get("chat")
        if (chatParam) {
          try {
            const chatData = JSON.parse(decodeURIComponent(chatParam))
            setChatId(chatData.id || null)
            setChatType(chatData.type || null)

            // Determine launch context from chat type
            if (chatData.type === "group") {
              setLaunchContext("group")
            } else if (chatData.type === "supergroup") {
              setLaunchContext("supergroup")
            } else if (chatData.type === "channel") {
              setLaunchContext("channel")
            }
          } catch {
            // Chat param parsing failed, continue with defaults
          }
        }

        // Check for inline query context
        const queryId = params.get("query_id")
        if (queryId) {
          setLaunchContext("inline_query")
        }
      }

      // Store initData for API requests
      if (data) {
        localStorage.setItem("telegramInitData", data)
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error("Failed to initialize Telegram"))
    } finally {
      setIsLoading(false)
    }
  }, [])

  const isGroup = launchContext === "group" || launchContext === "supergroup"
  const isTelegram = isTelegramWebApp()

  return {
    initData,
    user,
    startParam,
    chatId,
    chatType,
    launchContext,
    isLoading,
    error,
    isGroup,
    isTelegram,
  }
}

// ==========================================
// useWebApp Hook
// ==========================================

export function useWebApp(): UseWebAppReturn {
  const [isReady, setIsReady] = useState(false)
  const [webApp, setWebApp] = useState<typeof window.Telegram.WebApp | null>(null)

  useEffect(() => {
    if (typeof window === "undefined") return

    const app = window.Telegram?.WebApp
    if (app) {
      // Initialize WebApp
      app.ready()
      app.expand()

      // Set dark theme background
      if (app.themeParams) {
        document.body.style.backgroundColor = "#0F1419"
      }

      setWebApp(app)
      setIsReady(true)
    }
  }, [])

  const expand = useCallback(() => {
    webApp?.expand()
  }, [webApp])

  const close = useCallback(() => {
    webApp?.close()
  }, [webApp])

  const haptic = useCallback((type: "success" | "error" | "warning" | "light" | "medium" | "heavy") => {
    hapticFeedback(type)
  }, [])

  const showBack = useCallback((onClick: () => void) => {
    showBackButton(onClick)
  }, [])

  const hideBack = useCallback(() => {
    hideBackButton()
  }, [])

  return {
    webApp,
    isReady,
    platform: webApp?.platform || "unknown",
    colorScheme: webApp?.colorScheme || "dark",
    viewportHeight: webApp?.viewportHeight || 0,
    expand,
    close,
    haptic,
    showBackButton: showBack,
    hideBackButton: hideBack,
  }
}

// ==========================================
// useDeepLink Hook
// ==========================================

export type DeepLinkAction = "challenge" | "event" | "leaderboard" | "daily_reward" | "profile" | "wallet" | null

export interface UseDeepLinkReturn {
  action: DeepLinkAction
  targetId: string | null
  params: Record<string, string>
}

export function useDeepLink(startParam: string | null): UseDeepLinkReturn {
  const [action, setAction] = useState<DeepLinkAction>(null)
  const [targetId, setTargetId] = useState<string | null>(null)
  const [params, setParams] = useState<Record<string, string>>({})

  useEffect(() => {
    if (!startParam) {
      setAction(null)
      setTargetId(null)
      setParams({})
      return
    }

    // Parse startParam format: action_id or action_id_param1_value1
    const parts = startParam.split("_")

    if (parts.length >= 1) {
      const actionType = parts[0].toLowerCase()

      // Map action types
      switch (actionType) {
        case "challenge":
          setAction("challenge")
          setTargetId(parts[1] || null)
          break
        case "event":
          setAction("event")
          setTargetId(parts[1] || null)
          break
        case "leaderboard":
          setAction("leaderboard")
          break
        case "daily":
        case "reward":
          setAction("daily_reward")
          break
        case "profile":
          setAction("profile")
          setTargetId(parts[1] || null)
          break
        case "wallet":
          setAction("wallet")
          break
        default:
          // Try to parse as challenge_123 format
          if (parts.length >= 2 && !isNaN(Number(parts[1]))) {
            setAction(actionType as DeepLinkAction)
            setTargetId(parts[1])
          }
      }

      // Parse additional params (format: key_value pairs after action_id)
      if (parts.length > 2) {
        const additionalParams: Record<string, string> = {}
        for (let i = 2; i < parts.length - 1; i += 2) {
          if (parts[i + 1]) {
            additionalParams[parts[i]] = parts[i + 1]
          }
        }
        setParams(additionalParams)
      }
    }
  }, [startParam])

  return { action, targetId, params }
}
