"use client"

// ==========================================
// BANTAH - Group Context Hook
// ==========================================

import { useState, useEffect } from "react"
import { useTelegram, useDeepLink } from "./useTelegram"

// ==========================================
// Types
// ==========================================

export type InvitationType = "challenge" | "event" | "referral" | null

export interface UseGroupContextReturn {
  groupId: number | null
  targetUserId: number | null
  challengeId: string | null
  eventId: string | null
  invitationType: InvitationType
  isGroupContext: boolean
  groupName: string | null
}

// ==========================================
// useGroupContext Hook
// ==========================================

export function useGroupContext(): UseGroupContextReturn {
  const { chatId, chatType, startParam, isGroup } = useTelegram()
  const { action, targetId, params } = useDeepLink(startParam)

  const [groupId, setGroupId] = useState<number | null>(null)
  const [targetUserId, setTargetUserId] = useState<number | null>(null)
  const [challengeId, setChallengeId] = useState<string | null>(null)
  const [eventId, setEventId] = useState<string | null>(null)
  const [invitationType, setInvitationType] = useState<InvitationType>(null)
  const [groupName, setGroupName] = useState<string | null>(null)

  useEffect(() => {
    // Set group ID from chat context
    if (isGroup && chatId) {
      setGroupId(chatId)
    }

    // Parse deep link action
    if (action === "challenge" && targetId) {
      setChallengeId(targetId)
      setInvitationType("challenge")

      // Check for target user in params (challenge_123_user_456)
      if (params.user) {
        setTargetUserId(Number(params.user))
      }
    } else if (action === "event" && targetId) {
      setEventId(targetId)
      setInvitationType("event")
    }

    // Parse group param from startParam if present (format: ...&group=true or _group_123)
    if (params.group) {
      const parsedGroupId = Number(params.group)
      if (!isNaN(parsedGroupId)) {
        setGroupId(parsedGroupId)
      }
    }

    // Parse group name if provided
    if (params.groupname) {
      setGroupName(decodeURIComponent(params.groupname))
    }
  }, [chatId, chatType, isGroup, action, targetId, params])

  return {
    groupId,
    targetUserId,
    challengeId,
    eventId,
    invitationType,
    isGroupContext: isGroup || groupId !== null,
    groupName,
  }
}
