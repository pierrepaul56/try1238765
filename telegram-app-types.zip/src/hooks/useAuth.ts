"use client"

// ==========================================
// BANTAH - Auth Hook
// ==========================================

import { useState, useEffect, useCallback } from "react"
import type { TelegramUser } from "../types"
import { useTelegram } from "./useTelegram"
import { authenticateUser, ApiError } from "../services/api"

// ==========================================
// Types
// ==========================================

export interface UseAuthReturn {
  user: TelegramUser | null
  isLoading: boolean
  error: Error | null
  isAuthenticated: boolean
  isNewUser: boolean
  token: string | null
  logout: () => void
  retry: () => Promise<void>
}

// ==========================================
// Constants
// ==========================================

const AUTH_TOKEN_KEY = "authToken"
const AUTH_USER_KEY = "authUser"

// ==========================================
// useAuth Hook
// ==========================================

export function useAuth(): UseAuthReturn {
  const { initData, user: telegramUser, isLoading: telegramLoading, isTelegram } = useTelegram()

  const [user, setUser] = useState<TelegramUser | null>(null)
  const [token, setToken] = useState<string | null>(null)
  const [isNewUser, setIsNewUser] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)

  // Authenticate with backend
  const authenticate = useCallback(async () => {
    if (!initData) {
      setIsLoading(false)
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const response = await authenticateUser(initData)

      // Store auth data
      setUser(response.user)
      setToken(response.token)
      setIsNewUser(response.isNewUser)

      // Persist to localStorage
      localStorage.setItem(AUTH_TOKEN_KEY, response.token)
      localStorage.setItem(AUTH_USER_KEY, JSON.stringify(response.user))
    } catch (err) {
      const authError = err instanceof ApiError ? err : new Error("Authentication failed")
      setError(authError)

      // Try to use cached user data as fallback
      const cachedUser = localStorage.getItem(AUTH_USER_KEY)
      if (cachedUser) {
        try {
          setUser(JSON.parse(cachedUser))
        } catch {
          // Cache parse failed, clear it
          localStorage.removeItem(AUTH_USER_KEY)
        }
      }
    } finally {
      setIsLoading(false)
    }
  }, [initData])

  // Initial auth on mount
  useEffect(() => {
    if (telegramLoading) return

    // Check for existing auth
    const cachedToken = localStorage.getItem(AUTH_TOKEN_KEY)
    const cachedUser = localStorage.getItem(AUTH_USER_KEY)

    if (cachedToken && cachedUser) {
      try {
        setUser(JSON.parse(cachedUser))
        setToken(cachedToken)
      } catch {
        // Cache invalid, will re-authenticate
      }
    }

    // Authenticate if we have initData
    if (initData) {
      authenticate()
    } else if (!isTelegram) {
      // Not in Telegram, use cached data or show error
      setIsLoading(false)
      if (!cachedToken) {
        setError(new Error("Please open this app in Telegram"))
      }
    } else {
      setIsLoading(false)
    }
  }, [telegramLoading, initData, isTelegram, authenticate])

  // Listen for unauthorized events
  useEffect(() => {
    const handleUnauthorized = () => {
      setUser(null)
      setToken(null)
      setError(new Error("Session expired. Please restart the app."))
    }

    window.addEventListener("auth:unauthorized", handleUnauthorized)
    return () => window.removeEventListener("auth:unauthorized", handleUnauthorized)
  }, [])

  // Logout function
  const logout = useCallback(() => {
    localStorage.removeItem(AUTH_TOKEN_KEY)
    localStorage.removeItem(AUTH_USER_KEY)
    localStorage.removeItem("telegramInitData")
    setUser(null)
    setToken(null)
    setError(null)
  }, [])

  // Retry authentication
  const retry = useCallback(async () => {
    await authenticate()
  }, [authenticate])

  return {
    user: user || telegramUser,
    isLoading: isLoading || telegramLoading,
    error,
    isAuthenticated: Boolean(user || telegramUser) && Boolean(token),
    isNewUser,
    token,
    logout,
    retry,
  }
}
