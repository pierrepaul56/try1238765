// ==========================================
// BANTAH - TypeScript Type Definitions
// ==========================================

// Telegram User from initData
export interface TelegramUser {
  id: number
  username: string | null
  firstName: string
  lastName: string | null
  photoUrl: string | null
  isPremium: boolean
}

// Auth response from backend
export interface AuthResponse {
  user: TelegramUser
  token: string
  isNewUser: boolean
}

// User profile data
export interface UserProfile {
  id: number
  username: string | null
  firstName: string
  balance: number
  coins: number
  level: number
  xp: number
  totalWinnings: number
  createdAt: string
}

// Transaction item for wallet history
export interface TransactionItem {
  id: string
  type: "deposit" | "withdrawal" | "wager" | "win" | "loss" | "bonus" | "refund"
  amount: number
  description: string
  status: "pending" | "completed" | "failed" | "cancelled"
  timestamp: string
}

// Wallet data with transactions
export interface WalletData {
  balance: number
  coins: number
  currency: string
  lastUpdated: string
  transactions: TransactionItem[]
}

// Event/prediction market data
export interface EventData {
  id: string
  title: string
  description: string
  category: "sports" | "politics" | "entertainment" | "crypto" | "general"
  entryFee: number
  totalPool: number
  yesVotes: number
  noVotes: number
  deadline: string
  creator: string
  status: "active" | "pending" | "resolved" | "cancelled"
  outcome?: boolean | null
}

// P2P Challenge data
export interface ChallengeData {
  id: string
  title: string
  description: string
  wagerAmount: number
  status: "open" | "accepted" | "resolved" | "cancelled" | "expired"
  creator: {
    id: number
    username: string | null
    firstName: string
  }
  acceptor: {
    id: number
    username: string | null
    firstName: string
  } | null
  deadline: string
  createdAt: string
  winnerId?: number | null
}

// Leaderboard entry
export interface LeaderboardEntry {
  rank: number
  userId: number
  username: string | null
  firstName: string
  points: number
  level: number
  winRate: number
}

// Achievement/badge data
export interface AchievementData {
  id: string
  name: string
  description: string
  icon: string
  unlockedAt: string | null
  progress: number // 0-100
}

// API Response wrapper
export interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

// Pagination params
export interface PaginationParams {
  page: number
  limit: number
}

// Paginated response
export interface PaginatedResponse<T> {
  items: T[]
  total: number
  page: number
  limit: number
  hasMore: boolean
}

// Event categories for filtering
export type EventCategory = EventData["category"]

// Transaction types
export type TransactionType = TransactionItem["type"]

// Challenge status
export type ChallengeStatus = ChallengeData["status"]

// Event status
export type EventStatus = EventData["status"]
