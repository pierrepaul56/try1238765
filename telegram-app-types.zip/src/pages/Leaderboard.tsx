"use client"

// ==========================================
// BANTAH - Leaderboard Page
// ==========================================

import { useState } from "react"
import { useQuery } from "@tanstack/react-query"
import { useAuth } from "../hooks/useAuth"
import { getLeaderboard } from "../services/api"
import { formatNumber, formatWinRate } from "../utils/format"
import type { LeaderboardEntry } from "../types"

// ==========================================
// LeaderboardItem Component
// ==========================================

interface LeaderboardItemProps {
  entry: LeaderboardEntry
  isCurrentUser: boolean
}

function LeaderboardItem({ entry, isCurrentUser }: LeaderboardItemProps) {
  // Get rank styling
  const getRankStyle = () => {
    switch (entry.rank) {
      case 1:
        return { bg: "bg-gradient-to-r from-yellow-500/20 to-yellow-600/10", text: "text-yellow-400", medal: "🥇" }
      case 2:
        return { bg: "bg-gradient-to-r from-gray-400/20 to-gray-500/10", text: "text-gray-300", medal: "🥈" }
      case 3:
        return { bg: "bg-gradient-to-r from-orange-600/20 to-orange-700/10", text: "text-orange-400", medal: "🥉" }
      default:
        return { bg: isCurrentUser ? "bg-[#FF6B35]/20" : "bg-[#1A1F2E]", text: "text-gray-400", medal: null }
    }
  }

  const style = getRankStyle()

  return (
    <div
      className={`flex items-center gap-3 rounded-xl p-3 ${style.bg} ${isCurrentUser ? "ring-1 ring-[#FF6B35]" : ""}`}
    >
      {/* Rank */}
      <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${entry.rank <= 3 ? "" : "bg-[#252A3A]"}`}>
        {style.medal ? (
          <span className="text-xl">{style.medal}</span>
        ) : (
          <span className={`font-bold ${style.text}`}>{entry.rank}</span>
        )}
      </div>

      {/* Avatar */}
      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-[#FF6B35] to-[#e55a2a] text-sm font-bold text-white">
        {entry.firstName.charAt(0).toUpperCase()}
      </div>

      {/* User Info */}
      <div className="flex-1">
        <div className="flex items-center gap-2">
          <span className={`font-medium ${isCurrentUser ? "text-[#FF6B35]" : "text-white"}`}>
            {entry.username ? `@${entry.username}` : entry.firstName}
          </span>
          {isCurrentUser && <span className="text-xs text-[#FF6B35]">(You)</span>}
        </div>
        <div className="flex items-center gap-2 text-xs text-gray-400">
          <span className="rounded bg-[#252A3A] px-1.5 py-0.5">Lv. {entry.level}</span>
          <span>{formatWinRate(entry.winRate)} win</span>
        </div>
      </div>

      {/* Points */}
      <div className="text-right">
        <span className={`text-lg font-bold ${entry.rank <= 3 ? style.text : "text-white"}`}>
          {formatNumber(entry.points)}
        </span>
        <p className="text-xs text-gray-500">points</p>
      </div>
    </div>
  )
}

// ==========================================
// Category Filter
// ==========================================

type TimeFilter = "all" | "month" | "week"

interface CategoryFilterProps {
  selected: TimeFilter
  onChange: (filter: TimeFilter) => void
}

function CategoryFilter({ selected, onChange }: CategoryFilterProps) {
  const filters: { value: TimeFilter; label: string }[] = [
    { value: "all", label: "All Time" },
    { value: "month", label: "This Month" },
    { value: "week", label: "This Week" },
  ]

  return (
    <div className="flex gap-2 overflow-x-auto px-4 pb-4">
      {filters.map((filter) => (
        <button
          key={filter.value}
          onClick={() => onChange(filter.value)}
          className={`whitespace-nowrap rounded-full px-4 py-2 text-sm font-medium transition-colors ${
            selected === filter.value ? "bg-[#FF6B35] text-white" : "bg-[#1A1F2E] text-gray-400 hover:bg-[#252A3A]"
          }`}
        >
          {filter.label}
        </button>
      ))}
    </div>
  )
}

// ==========================================
// User Position Banner
// ==========================================

interface UserPositionBannerProps {
  position: number
  totalUsers: number
}

function UserPositionBanner({ position, totalUsers }: UserPositionBannerProps) {
  const percentile = Math.round((1 - position / totalUsers) * 100)

  return (
    <div className="mx-4 mb-4 rounded-xl bg-gradient-to-r from-[#FF6B35]/20 to-[#e55a2a]/10 p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-400">Your Rank</p>
          <p className="text-2xl font-bold text-[#FF6B35]">#{position}</p>
        </div>
        <div className="text-right">
          <p className="text-sm text-gray-400">Top</p>
          <p className="text-2xl font-bold text-white">{percentile}%</p>
        </div>
      </div>
    </div>
  )
}

// ==========================================
// Loading Skeleton
// ==========================================

function LeaderboardSkeleton() {
  return (
    <div className="animate-pulse">
      {/* Filter skeleton */}
      <div className="flex gap-2 px-4 pb-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="h-9 w-24 rounded-full bg-[#1A1F2E]" />
        ))}
      </div>

      {/* Banner skeleton */}
      <div className="mx-4 mb-4 h-20 rounded-xl bg-[#1A1F2E]" />

      {/* List skeleton */}
      <div className="space-y-2 px-4">
        {[...Array(10)].map((_, i) => (
          <div key={i} className="h-16 rounded-xl bg-[#1A1F2E]" />
        ))}
      </div>
    </div>
  )
}

// ==========================================
// Leaderboard Page Component
// ==========================================

export function Leaderboard() {
  const { user } = useAuth()
  const [timeFilter, setTimeFilter] = useState<TimeFilter>("all")

  // Fetch leaderboard
  const {
    data: leaderboard,
    isLoading,
    error,
    refetch,
  } = useQuery({
    queryKey: ["leaderboard", timeFilter],
    queryFn: () => getLeaderboard(50),
    staleTime: 2 * 60 * 1000, // 2 minutes
  })

  // Find current user position
  const currentUserPosition = leaderboard?.findIndex((entry) => entry.userId === user?.id)
  const userRank = currentUserPosition !== undefined && currentUserPosition !== -1 ? currentUserPosition + 1 : null

  // Error state
  if (error) {
    return (
      <div className="flex h-full flex-col items-center justify-center p-4">
        <p className="mb-4 text-center text-gray-400">Failed to load leaderboard</p>
        <button onClick={() => refetch()} className="rounded-lg bg-[#FF6B35] px-4 py-2 font-medium text-white">
          Retry
        </button>
      </div>
    )
  }

  // Loading state
  if (isLoading || !leaderboard) {
    return <LeaderboardSkeleton />
  }

  return (
    <div className="min-h-full bg-[#0F1419] pb-4 pt-2">
      {/* Header */}
      <div className="px-4 pb-4">
        <h1 className="text-xl font-bold text-white">Leaderboard</h1>
        <p className="text-sm text-gray-400">Top players this {timeFilter === "all" ? "season" : timeFilter}</p>
      </div>

      {/* Time Filter */}
      <CategoryFilter selected={timeFilter} onChange={setTimeFilter} />

      {/* User Position Banner */}
      {userRank && <UserPositionBanner position={userRank} totalUsers={leaderboard.length} />}

      {/* Leaderboard List */}
      <div className="space-y-2 px-4">
        {leaderboard.map((entry) => (
          <LeaderboardItem key={entry.userId} entry={entry} isCurrentUser={entry.userId === user?.id} />
        ))}
      </div>

      {/* Load More (placeholder for pagination) */}
      {leaderboard.length >= 50 && (
        <div className="px-4 pt-4">
          <button className="w-full rounded-xl bg-[#1A1F2E] py-3 text-center text-gray-400 transition-colors hover:bg-[#252A3A]">
            Load More
          </button>
        </div>
      )}
    </div>
  )
}

export default Leaderboard
