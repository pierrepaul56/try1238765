"use client"

// ==========================================
// BANTAH - Home/Dashboard Page
// ==========================================

import { useQuery } from "@tanstack/react-query"
import { useAuth } from "../hooks/useAuth"
import { getWallet, getEvents, getChallenges } from "../services/api"
import { formatBalance, formatNumber, getTimeRemaining, getCategoryColor } from "../utils/format"
import type { EventData, ChallengeData } from "../types"

// ==========================================
// Quick Stats Card
// ==========================================

interface QuickStatProps {
  icon: string
  label: string
  value: string | number
  color?: string
}

function QuickStat({ icon, label, value, color = "#FF6B35" }: QuickStatProps) {
  return (
    <div className="flex flex-col items-center rounded-xl bg-[#1A1F2E] p-3">
      <span className="mb-1 text-xl">{icon}</span>
      <span className="text-xs text-gray-400">{label}</span>
      <span className="text-lg font-bold" style={{ color }}>
        {value}
      </span>
    </div>
  )
}

// ==========================================
// Featured Event Card (Mini)
// ==========================================

interface FeaturedEventProps {
  event: EventData
  onClick: () => void
}

function FeaturedEvent({ event, onClick }: FeaturedEventProps) {
  const categoryColor = getCategoryColor(event.category)
  const totalVotes = event.yesVotes + event.noVotes
  const yesPercentage = totalVotes > 0 ? Math.round((event.yesVotes / totalVotes) * 100) : 50

  return (
    <button
      onClick={onClick}
      className="w-full rounded-xl bg-[#1A1F2E] p-3 text-left transition-colors hover:bg-[#252A3A]"
    >
      <div className="mb-2 flex items-start justify-between">
        <span
          className="rounded-full px-2 py-0.5 text-xs font-medium text-white"
          style={{ backgroundColor: categoryColor }}
        >
          {event.category}
        </span>
        <span className="text-xs text-gray-400">{getTimeRemaining(event.deadline)}</span>
      </div>
      <h3 className="mb-2 line-clamp-2 text-sm font-medium text-white">{event.title}</h3>
      <div className="flex items-center justify-between text-xs">
        <span className="text-gray-400">Pool: {formatBalance(event.totalPool)}</span>
        <span className="text-green-400">{yesPercentage}% Yes</span>
      </div>
    </button>
  )
}

// ==========================================
// Challenge Card (Mini)
// ==========================================

interface MiniChallengeProps {
  challenge: ChallengeData
  onClick: () => void
}

function MiniChallenge({ challenge, onClick }: MiniChallengeProps) {
  const statusColors: Record<string, string> = {
    open: "#FF6B35",
    accepted: "#22C55E",
    resolved: "#3B82F6",
    cancelled: "#6B7280",
    expired: "#6B7280",
  }

  return (
    <button
      onClick={onClick}
      className="w-full rounded-xl bg-[#1A1F2E] p-3 text-left transition-colors hover:bg-[#252A3A]"
    >
      <div className="mb-2 flex items-start justify-between">
        <span
          className="rounded-full px-2 py-0.5 text-xs font-medium text-white"
          style={{ backgroundColor: statusColors[challenge.status] }}
        >
          {challenge.status}
        </span>
        <span className="text-sm font-bold text-[#FF6B35]">{formatBalance(challenge.wagerAmount)}</span>
      </div>
      <h3 className="mb-1 line-clamp-1 text-sm font-medium text-white">{challenge.title}</h3>
      <p className="text-xs text-gray-400">vs {challenge.acceptor?.firstName || "Anyone"}</p>
    </button>
  )
}

// ==========================================
// Quick Action Button
// ==========================================

interface QuickActionProps {
  icon: string
  label: string
  onClick: () => void
}

function QuickAction({ icon, label, onClick }: QuickActionProps) {
  return (
    <button
      onClick={onClick}
      className="flex flex-1 flex-col items-center gap-2 rounded-xl bg-gradient-to-br from-[#FF6B35] to-[#e55a2a] p-4 text-white transition-transform active:scale-95"
    >
      <span className="text-2xl">{icon}</span>
      <span className="text-sm font-medium">{label}</span>
    </button>
  )
}

// ==========================================
// Loading Skeleton
// ==========================================

function HomeSkeleton() {
  return (
    <div className="animate-pulse space-y-6 p-4">
      {/* Greeting skeleton */}
      <div className="h-8 w-48 rounded bg-[#1A1F2E]" />

      {/* Stats skeleton */}
      <div className="grid grid-cols-4 gap-3">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-20 rounded-xl bg-[#1A1F2E]" />
        ))}
      </div>

      {/* Actions skeleton */}
      <div className="flex gap-3">
        <div className="h-20 flex-1 rounded-xl bg-[#1A1F2E]" />
        <div className="h-20 flex-1 rounded-xl bg-[#1A1F2E]" />
      </div>

      {/* Featured skeleton */}
      <div className="space-y-3">
        <div className="h-5 w-32 rounded bg-[#1A1F2E]" />
        <div className="flex gap-3 overflow-hidden">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="h-28 w-48 flex-shrink-0 rounded-xl bg-[#1A1F2E]" />
          ))}
        </div>
      </div>
    </div>
  )
}

// ==========================================
// Home Page Component
// ==========================================

export function Home() {
  const { user } = useAuth()

  // Fetch wallet data
  const { data: wallet, isLoading: walletLoading } = useQuery({
    queryKey: ["wallet"],
    queryFn: getWallet,
    staleTime: 2 * 60 * 1000,
  })

  // Fetch featured events
  const { data: eventsData, isLoading: eventsLoading } = useQuery({
    queryKey: ["events", "featured"],
    queryFn: () => getEvents(3, 0),
    staleTime: 2 * 60 * 1000,
  })

  // Fetch user challenges
  const { data: challenges, isLoading: challengesLoading } = useQuery({
    queryKey: ["challenges"],
    queryFn: () => getChallenges(),
    staleTime: 2 * 60 * 1000,
  })

  const isLoading = walletLoading || eventsLoading || challengesLoading

  if (isLoading) {
    return <HomeSkeleton />
  }

  const featuredEvents = eventsData?.events.slice(0, 3) || []
  const recentChallenges = challenges?.slice(0, 3) || []

  // Navigate handlers (would use router in real app)
  const navigateToEvents = () => {
    window.dispatchEvent(new CustomEvent("navigate", { detail: "/events" }))
  }

  const navigateToChallenges = () => {
    window.dispatchEvent(new CustomEvent("navigate", { detail: "/challenges" }))
  }

  return (
    <div className="min-h-full bg-[#0F1419] p-4">
      {/* Greeting */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white">
          Welcome back, {user?.username ? `@${user.username}` : user?.firstName || "Player"}!
        </h1>
        <p className="text-gray-400">Ready to make some predictions?</p>
      </div>

      {/* Quick Stats */}
      <div className="mb-6 grid grid-cols-4 gap-3">
        <QuickStat icon="💰" label="Balance" value={wallet ? formatBalance(wallet.balance) : "₦0"} />
        <QuickStat icon="🏆" label="Level" value={12} color="#FFD700" />
        <QuickStat icon="🪙" label="Coins" value={wallet ? formatNumber(wallet.coins) : "0"} />
        <QuickStat icon="🔥" label="Streak" value="5d" color="#EF4444" />
      </div>

      {/* Quick Actions */}
      <div className="mb-6 flex gap-3">
        <QuickAction icon="🎯" label="Predict" onClick={navigateToEvents} />
        <QuickAction icon="⚔️" label="Challenge" onClick={navigateToChallenges} />
      </div>

      {/* Featured Events */}
      {featuredEvents.length > 0 && (
        <div className="mb-6">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-white">Featured Events</h2>
            <button onClick={navigateToEvents} className="text-sm text-[#FF6B35]">
              See all
            </button>
          </div>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {featuredEvents.map((event) => (
              <div key={event.id} className="w-48 flex-shrink-0">
                <FeaturedEvent event={event} onClick={navigateToEvents} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Your Challenges */}
      {recentChallenges.length > 0 && (
        <div className="mb-6">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-white">Your Challenges</h2>
            <button onClick={navigateToChallenges} className="text-sm text-[#FF6B35]">
              See all
            </button>
          </div>
          <div className="space-y-2">
            {recentChallenges.map((challenge) => (
              <MiniChallenge key={challenge.id} challenge={challenge} onClick={navigateToChallenges} />
            ))}
          </div>
        </div>
      )}

      {/* Empty state if no content */}
      {featuredEvents.length === 0 && recentChallenges.length === 0 && (
        <div className="rounded-xl bg-[#1A1F2E] p-6 text-center">
          <p className="mb-2 text-lg text-white">No active events yet</p>
          <p className="text-sm text-gray-400">Check back soon for new predictions!</p>
        </div>
      )}
    </div>
  )
}

export default Home
