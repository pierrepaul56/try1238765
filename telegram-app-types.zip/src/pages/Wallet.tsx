"use client"

import { useQuery } from "@tanstack/react-query"
import { ArrowDownToLine, ArrowUpFromLine, HandCoins, RefreshCw } from "lucide-react"
import { useAuth } from "../hooks/useAuth"
import { useWebApp } from "../hooks/useTelegram"
import { getWallet } from "../services/api"
import { BalanceCard } from "../components/Cards/BalanceCard"
import { TransactionItem } from "../components/Cards/TransactionItem"
import type { TransactionItem as TransactionItemType } from "../types"

// Group transactions by date
function groupTransactionsByDate(transactions: TransactionItemType[]) {
  const groups: Record<string, TransactionItemType[]> = {}
  const now = new Date()
  const today = now.toDateString()
  const yesterday = new Date(now.setDate(now.getDate() - 1)).toDateString()

  transactions.forEach((tx) => {
    const txDate = new Date(tx.timestamp).toDateString()
    let label: string

    if (txDate === today) {
      label = "Today"
    } else if (txDate === yesterday) {
      label = "Yesterday"
    } else {
      label = new Date(tx.timestamp).toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
      })
    }

    if (!groups[label]) {
      groups[label] = []
    }
    groups[label].push(tx)
  })

  return groups
}

export function WalletPage() {
  const { isAuthenticated } = useAuth()
  const { haptic } = useWebApp()

  const {
    data: wallet,
    isLoading,
    error,
    refetch,
    isRefetching,
  } = useQuery({
    queryKey: ["wallet"],
    queryFn: getWallet,
    enabled: isAuthenticated,
    staleTime: 5 * 60 * 1000, // 5 minutes
  })

  const handleRefresh = () => {
    haptic("medium")
    refetch()
  }

  const handleActionClick = (action: string) => {
    haptic("light")
    // TODO: Open respective modal based on action
    console.log(`${action} clicked`)
  }

  // Loading skeleton
  if (isLoading) {
    return (
      <div className="space-y-4 p-4">
        <div className="h-40 animate-pulse rounded-2xl bg-[#1A1F26]" />
        <div className="grid grid-cols-3 gap-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 animate-pulse rounded-xl bg-[#1A1F26]" />
          ))}
        </div>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-20 animate-pulse rounded-xl bg-[#1A1F26]" />
          ))}
        </div>
      </div>
    )
  }

  // Error state
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center">
        <div className="mb-4 rounded-full bg-red-500/20 p-4">
          <RefreshCw className="h-8 w-8 text-red-500" />
        </div>
        <h3 className="mb-2 text-lg font-semibold text-white">Failed to load wallet</h3>
        <p className="mb-4 text-sm text-gray-400">{error.message}</p>
        <button
          onClick={handleRefresh}
          className="rounded-xl bg-[#FF6B35] px-6 py-3 font-medium text-white transition-colors hover:bg-[#FF6B35]/90"
        >
          Try Again
        </button>
      </div>
    )
  }

  if (!wallet) return null

  const groupedTransactions = groupTransactionsByDate(wallet.transactions)
  const transactionGroups = Object.entries(groupedTransactions)

  return (
    <div className="space-y-4 p-4">
      {/* Balance Card */}
      <BalanceCard
        balance={wallet.balance}
        coins={wallet.coins}
        lastUpdated={wallet.lastUpdated}
        onRefresh={handleRefresh}
        isRefreshing={isRefetching}
      />

      {/* Action Buttons */}
      <div className="grid grid-cols-3 gap-3">
        <button
          onClick={() => handleActionClick("deposit")}
          className="flex flex-col items-center gap-2 rounded-xl bg-[#FF6B35] p-4 font-medium text-white transition-transform active:scale-95"
        >
          <ArrowDownToLine className="h-5 w-5" />
          <span className="text-sm">Deposit</span>
        </button>
        <button
          onClick={() => handleActionClick("withdraw")}
          className="flex flex-col items-center gap-2 rounded-xl bg-[#1A1F26] p-4 font-medium text-white transition-transform active:scale-95 hover:bg-[#1E252D]"
        >
          <ArrowUpFromLine className="h-5 w-5" />
          <span className="text-sm">Withdraw</span>
        </button>
        <button
          onClick={() => handleActionClick("request")}
          className="flex flex-col items-center gap-2 rounded-xl bg-[#1A1F26] p-4 font-medium text-white transition-transform active:scale-95 hover:bg-[#1E252D]"
        >
          <HandCoins className="h-5 w-5" />
          <span className="text-sm">Request</span>
        </button>
      </div>

      {/* Transaction History */}
      <div className="space-y-4">
        <h2 className="text-lg font-semibold text-white">Transaction History</h2>

        {transactionGroups.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-xl bg-[#1A1F26] py-12 text-center">
            <div className="mb-3 rounded-full bg-gray-700/50 p-4">
              <ArrowDownToLine className="h-6 w-6 text-gray-500" />
            </div>
            <p className="text-gray-400">No transactions yet</p>
            <p className="text-sm text-gray-500">Your transaction history will appear here</p>
          </div>
        ) : (
          transactionGroups.map(([date, transactions]) => (
            <div key={date} className="space-y-2">
              <h3 className="text-sm font-medium text-gray-400">{date}</h3>
              <div className="space-y-2">
                {transactions.map((tx) => (
                  <TransactionItem key={tx.id} transaction={tx} />
                ))}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}

export { WalletPage as Wallet }
