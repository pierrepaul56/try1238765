"use client"

import { useState } from "react"
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { Plus, RefreshCw, Swords, X, AlertCircle } from "lucide-react"
import { useAuth } from "../hooks/useAuth"
import { useWebApp } from "../hooks/useTelegram"
import { getChallenges, createChallenge, getWallet } from "../services/api"
import { ChallengeCard } from "../components/Cards/ChallengeCard"
import { ChallengeDetailModal } from "../components/Modals/ChallengeDetailModal"
import { formatBalance } from "../utils/format"
import type { ChallengeData, EventCategory } from "../types"

const CATEGORIES: EventCategory[] = ["sports", "politics", "entertainment", "crypto", "general"]

export function ChallengesPage() {
  const { isAuthenticated, user } = useAuth()
  const { haptic } = useWebApp()
  const queryClient = useQueryClient()

  const [showCreateModal, setShowCreateModal] = useState(false)
  const [selectedChallenge, setSelectedChallenge] = useState<ChallengeData | null>(null)

  // Form state
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [category, setCategory] = useState<EventCategory>("general")
  const [wagerAmount, setWagerAmount] = useState("")
  const [deadline, setDeadline] = useState("")
  const [agreedToTerms, setAgreedToTerms] = useState(false)

  const {
    data: challenges,
    isLoading,
    error,
    refetch,
    isRefetching,
  } = useQuery({
    queryKey: ["challenges"],
    queryFn: () => getChallenges(),
    enabled: isAuthenticated,
    refetchInterval: 30000, // Poll every 30 seconds
  })

  const { data: wallet } = useQuery({
    queryKey: ["wallet"],
    queryFn: getWallet,
    enabled: isAuthenticated,
  })

  const createMutation = useMutation({
    mutationFn: () => createChallenge(title, description, Number.parseFloat(wagerAmount), deadline),
    onSuccess: () => {
      haptic("success")
      queryClient.invalidateQueries({ queryKey: ["challenges"] })
      queryClient.invalidateQueries({ queryKey: ["wallet"] })
      resetForm()
      setShowCreateModal(false)
    },
    onError: () => {
      haptic("error")
    },
  })

  const resetForm = () => {
    setTitle("")
    setDescription("")
    setCategory("general")
    setWagerAmount("")
    setDeadline("")
    setAgreedToTerms(false)
  }

  const handleRefresh = () => {
    haptic("medium")
    refetch()
  }

  // Form validation
  const wagerNum = Number.parseFloat(wagerAmount) || 0
  const hasInsufficientFunds = wallet && wagerNum > wallet.balance
  const isDeadlineValid = deadline && new Date(deadline) > new Date()
  const canSubmit =
    title.trim().length > 0 &&
    description.trim().length > 0 &&
    wagerNum >= 100 &&
    !hasInsufficientFunds &&
    isDeadlineValid &&
    agreedToTerms

  // Separate challenges by type
  const myChallenges = challenges?.filter((c) => c.creator.id === user?.id) ?? []
  const acceptedChallenges = challenges?.filter((c) => c.acceptor?.id === user?.id) ?? []
  const availableChallenges = challenges?.filter((c) => c.status === "open" && c.creator.id !== user?.id) ?? []

  // Loading skeleton
  if (isLoading) {
    return (
      <div className="space-y-4 p-4">
        <div className="h-12 animate-pulse rounded-xl bg-[#1A1F26]" />
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-32 animate-pulse rounded-xl bg-[#1A1F26]" />
          ))}
        </div>
      </div>
    )
  }

  // Error state
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center">
        <div className="mb-4 rounded-full bg-red-500/20 p-4">
          <RefreshCw className="h-8 w-8 text-red-500" />
        </div>
        <h3 className="mb-2 text-lg font-semibold text-white">Failed to load challenges</h3>
        <p className="mb-4 text-sm text-gray-400">{error.message}</p>
        <button
          onClick={handleRefresh}
          className="rounded-xl bg-[#FF6B35] px-6 py-3 font-medium text-white transition-colors hover:bg-[#FF6B35]/90"
        >
          Try Again
        </button>
      </div>
    )
  }

  return (
    <div className="space-y-6 p-4">
      {/* Header with Create Button */}
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-white">Challenges</h1>
        <button
          onClick={() => {
            haptic("light")
            setShowCreateModal(true)
          }}
          className="flex items-center gap-2 rounded-xl bg-[#FF6B35] px-4 py-2 font-medium text-white transition-transform active:scale-95"
        >
          <Plus className="h-5 w-5" />
          Create
        </button>
      </div>

      {/* Refresh indicator */}
      {isRefetching && (
        <div className="flex items-center justify-center gap-2 text-sm text-gray-400">
          <RefreshCw className="h-4 w-4 animate-spin" />
          <span>Updating...</span>
        </div>
      )}

      {/* Available Challenges */}
      {availableChallenges.length > 0 && (
        <section>
          <h2 className="mb-3 text-sm font-medium text-gray-400">Available Challenges</h2>
          <div className="space-y-3">
            {availableChallenges.map((challenge) => (
              <ChallengeCard
                key={challenge.id}
                challenge={challenge}
                onClick={() => {
                  haptic("light")
                  setSelectedChallenge(challenge)
                }}
              />
            ))}
          </div>
        </section>
      )}

      {/* Your Challenges */}
      <section>
        <h2 className="mb-3 text-sm font-medium text-gray-400">Your Challenges</h2>
        {myChallenges.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-xl bg-[#1A1F26] py-8 text-center">
            <Swords className="mb-2 h-8 w-8 text-gray-500" />
            <p className="text-gray-400">No challenges created yet</p>
            <p className="text-sm text-gray-500">Create one to challenge others!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {myChallenges.map((challenge) => (
              <ChallengeCard
                key={challenge.id}
                challenge={challenge}
                onClick={() => {
                  haptic("light")
                  setSelectedChallenge(challenge)
                }}
              />
            ))}
          </div>
        )}
      </section>

      {/* Accepted Challenges */}
      <section>
        <h2 className="mb-3 text-sm font-medium text-gray-400">Accepted Challenges</h2>
        {acceptedChallenges.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-xl bg-[#1A1F26] py-8 text-center">
            <Swords className="mb-2 h-8 w-8 text-gray-500" />
            <p className="text-gray-400">No accepted challenges</p>
            <p className="text-sm text-gray-500">Accept a challenge to compete!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {acceptedChallenges.map((challenge) => (
              <ChallengeCard
                key={challenge.id}
                challenge={challenge}
                onClick={() => {
                  haptic("light")
                  setSelectedChallenge(challenge)
                }}
              />
            ))}
          </div>
        )}
      </section>

      {/* Create Challenge Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm">
          <div className="max-h-[90vh] w-full overflow-y-auto rounded-t-3xl bg-[#0F1419] pb-safe">
            {/* Header */}
            <div className="sticky top-0 z-10 flex items-center justify-between border-b border-gray-800 bg-[#0F1419] p-4">
              <h2 className="text-lg font-semibold text-white">Create Challenge</h2>
              <button
                onClick={() => setShowCreateModal(false)}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-gray-800 text-gray-400 hover:bg-gray-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-4 p-4">
              {/* Title */}
              <div>
                <label className="mb-2 block text-sm font-medium text-white">Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Enter challenge title"
                  className="w-full rounded-xl bg-[#1A1F26] p-4 text-white outline-none ring-2 ring-transparent placeholder:text-gray-500 focus:ring-[#FF6B35]"
                />
              </div>

              {/* Description */}
              <div>
                <div className="mb-2 flex items-center justify-between">
                  <label className="text-sm font-medium text-white">Description</label>
                  <span className="text-xs text-gray-400">{description.length}/200</span>
                </div>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value.slice(0, 200))}
                  placeholder="Describe your challenge..."
                  rows={3}
                  className="w-full resize-none rounded-xl bg-[#1A1F26] p-4 text-white outline-none ring-2 ring-transparent placeholder:text-gray-500 focus:ring-[#FF6B35]"
                />
              </div>

              {/* Category */}
              <div>
                <label className="mb-2 block text-sm font-medium text-white">Category</label>
                <div className="flex flex-wrap gap-2">
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => {
                        haptic("light")
                        setCategory(cat)
                      }}
                      className={`rounded-full px-4 py-2 text-sm font-medium capitalize transition-colors ${
                        category === cat ? "bg-[#FF6B35] text-white" : "bg-[#1A1F26] text-gray-400 hover:bg-[#1E252D]"
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Wager Amount */}
              <div>
                <div className="mb-2 flex items-center justify-between">
                  <label className="text-sm font-medium text-white">Wager Amount</label>
                  {wallet && <span className="text-xs text-gray-400">Balance: {formatBalance(wallet.balance)}</span>}
                </div>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-lg text-gray-400">₦</span>
                  <input
                    type="number"
                    value={wagerAmount}
                    onChange={(e) => setWagerAmount(e.target.value)}
                    placeholder="Min: 100"
                    min={100}
                    className="w-full rounded-xl bg-[#1A1F26] py-4 pl-10 pr-4 text-white outline-none ring-2 ring-transparent placeholder:text-gray-500 focus:ring-[#FF6B35]"
                  />
                </div>
                {hasInsufficientFunds && (
                  <div className="mt-2 flex items-center gap-1 text-sm text-red-400">
                    <AlertCircle className="h-4 w-4" />
                    <span>Insufficient balance</span>
                  </div>
                )}
              </div>

              {/* Deadline */}
              <div>
                <label className="mb-2 block text-sm font-medium text-white">Deadline</label>
                <input
                  type="datetime-local"
                  value={deadline}
                  onChange={(e) => setDeadline(e.target.value)}
                  min={new Date().toISOString().slice(0, 16)}
                  className="w-full rounded-xl bg-[#1A1F26] p-4 text-white outline-none ring-2 ring-transparent focus:ring-[#FF6B35]"
                />
                {deadline && !isDeadlineValid && (
                  <p className="mt-2 text-sm text-red-400">Deadline must be in the future</p>
                )}
              </div>

              {/* Terms */}
              <label className="flex items-start gap-3">
                <input
                  type="checkbox"
                  checked={agreedToTerms}
                  onChange={(e) => setAgreedToTerms(e.target.checked)}
                  className="mt-1 h-5 w-5 rounded border-gray-600 bg-[#1A1F26] text-[#FF6B35] focus:ring-[#FF6B35]"
                />
                <span className="text-sm text-gray-400">
                  I understand that the wager amount will be held until the challenge is resolved or cancelled
                </span>
              </label>

              {/* Submit Button */}
              <button
                onClick={() => createMutation.mutate()}
                disabled={!canSubmit || createMutation.isPending}
                className="w-full rounded-xl bg-[#FF6B35] py-4 text-lg font-semibold text-white transition-all hover:bg-[#FF6B35]/90 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {createMutation.isPending ? "Creating..." : "Create Challenge"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Challenge Detail Modal */}
      {selectedChallenge && (
        <ChallengeDetailModal
          challenge={selectedChallenge}
          onClose={() => setSelectedChallenge(null)}
          currentUserId={user?.id}
        />
      )}
    </div>
  )
}

export { ChallengesPage as Challenges }
