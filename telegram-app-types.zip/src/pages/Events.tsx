"use client"

import { useState } from "react"
import { useQuery } from "@tanstack/react-query"
import { Search, Filter, X, RefreshCw } from "lucide-react"
import { useAuth } from "../hooks/useAuth"
import { useWebApp } from "../hooks/useTelegram"
import { getEvents, getWallet } from "../services/api"
import { EventCard } from "../components/Cards/EventCard"
import { EventDetailModal } from "../components/Modals/EventDetailModal"
import type { EventData, EventCategory, EventStatus } from "../types"

const CATEGORIES: (EventCategory | "all")[] = ["all", "sports", "politics", "entertainment", "crypto", "general"]
const STATUSES: (EventStatus | "all")[] = ["all", "active", "pending", "resolved", "cancelled"]

export function EventsPage() {
  const { isAuthenticated } = useAuth()
  const { haptic } = useWebApp()

  const [search, setSearch] = useState("")
  const [category, setCategory] = useState<EventCategory | "all">("all")
  const [status, setStatus] = useState<EventStatus | "all">("all")
  const [selectedEvent, setSelectedEvent] = useState<EventData | null>(null)
  const [page, setPage] = useState(0)

  const {
    data: eventsData,
    isLoading,
    error,
    refetch,
    isRefetching,
  } = useQuery({
    queryKey: ["events", page],
    queryFn: () => getEvents(20, page * 20),
    enabled: isAuthenticated,
  })

  const { data: wallet } = useQuery({
    queryKey: ["wallet"],
    queryFn: getWallet,
    enabled: isAuthenticated,
  })

  // Filter events client-side
  const filteredEvents =
    eventsData?.events.filter((event) => {
      const matchesSearch = event.title.toLowerCase().includes(search.toLowerCase())
      const matchesCategory = category === "all" || event.category === category
      const matchesStatus = status === "all" || event.status === status
      return matchesSearch && matchesCategory && matchesStatus
    }) ?? []

  const hasFilters = search !== "" || category !== "all" || status !== "all"

  const handleRefresh = () => {
    haptic("medium")
    refetch()
  }

  const clearFilters = () => {
    haptic("light")
    setSearch("")
    setCategory("all")
    setStatus("all")
  }

  const handleEventClick = (event: EventData) => {
    haptic("light")
    setSelectedEvent(event)
  }

  const handleLoadMore = () => {
    haptic("light")
    setPage((prev) => prev + 1)
  }

  // Loading skeleton
  if (isLoading) {
    return (
      <div className="space-y-4 p-4">
        <div className="h-12 animate-pulse rounded-xl bg-[#1A1F26]" />
        <div className="flex gap-2 overflow-x-auto">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-8 w-20 shrink-0 animate-pulse rounded-full bg-[#1A1F26]" />
          ))}
        </div>
        <div className="space-y-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-40 animate-pulse rounded-xl bg-[#1A1F26]" />
          ))}
        </div>
      </div>
    )
  }

  // Error state
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center">
        <div className="mb-4 rounded-full bg-red-500/20 p-4">
          <RefreshCw className="h-8 w-8 text-red-500" />
        </div>
        <h3 className="mb-2 text-lg font-semibold text-white">Failed to load events</h3>
        <p className="mb-4 text-sm text-gray-400">{error.message}</p>
        <button
          onClick={handleRefresh}
          className="rounded-xl bg-[#FF6B35] px-6 py-3 font-medium text-white transition-colors hover:bg-[#FF6B35]/90"
        >
          Try Again
        </button>
      </div>
    )
  }

  return (
    <div className="space-y-4 p-4">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search events..."
          className="w-full rounded-xl bg-[#1A1F26] py-3 pl-12 pr-4 text-white outline-none ring-2 ring-transparent placeholder:text-gray-500 focus:ring-[#FF6B35]"
        />
      </div>

      {/* Category Filter */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => {
              haptic("light")
              setCategory(cat)
            }}
            className={`shrink-0 rounded-full px-4 py-2 text-sm font-medium capitalize transition-colors ${
              category === cat ? "bg-[#FF6B35] text-white" : "bg-[#1A1F26] text-gray-400 hover:bg-[#1E252D]"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Status Filter */}
      <div className="flex items-center gap-2">
        <Filter className="h-4 w-4 text-gray-400" />
        <div className="flex gap-2 overflow-x-auto scrollbar-hide">
          {STATUSES.map((s) => (
            <button
              key={s}
              onClick={() => {
                haptic("light")
                setStatus(s)
              }}
              className={`shrink-0 rounded-full px-3 py-1 text-xs font-medium capitalize transition-colors ${
                status === s ? "bg-[#FF6B35] text-white" : "bg-[#1A1F26] text-gray-400 hover:bg-[#1E252D]"
              }`}
            >
              {s}
            </button>
          ))}
        </div>
        {hasFilters && (
          <button onClick={clearFilters} className="ml-auto flex shrink-0 items-center gap-1 text-sm text-[#FF6B35]">
            <X className="h-4 w-4" />
            Clear
          </button>
        )}
      </div>

      {/* Refresh indicator */}
      {isRefetching && (
        <div className="flex items-center justify-center gap-2 text-sm text-gray-400">
          <RefreshCw className="h-4 w-4 animate-spin" />
          <span>Updating...</span>
        </div>
      )}

      {/* Events List */}
      {filteredEvents.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-xl bg-[#1A1F26] py-12 text-center">
          <div className="mb-3 rounded-full bg-gray-700/50 p-4">
            <Search className="h-6 w-6 text-gray-500" />
          </div>
          <p className="text-gray-400">No events found</p>
          <p className="text-sm text-gray-500">
            {hasFilters ? "Try adjusting your filters" : "Check back later for new events"}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredEvents.map((event) => (
            <EventCard key={event.id} event={event} onClick={() => handleEventClick(event)} />
          ))}

          {/* Load More */}
          {eventsData && eventsData.total > (page + 1) * 20 && (
            <button
              onClick={handleLoadMore}
              className="w-full rounded-xl bg-[#1A1F26] py-3 font-medium text-gray-400 transition-colors hover:bg-[#1E252D]"
            >
              Load More
            </button>
          )}
        </div>
      )}

      {/* Event Detail Modal */}
      {selectedEvent && (
        <EventDetailModal event={selectedEvent} onClose={() => setSelectedEvent(null)} userBalance={wallet?.balance} />
      )}
    </div>
  )
}

export { EventsPage as Events }
