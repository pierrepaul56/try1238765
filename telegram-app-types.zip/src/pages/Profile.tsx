"use client"

// ==========================================
// BANTAH - Profile Page
// ==========================================

import { useQuery } from "@tanstack/react-query"
import { useAuth } from "../hooks/useAuth"
import { getUserProfile, getAchievements, getUserStats } from "../services/api"
import { formatBalance, formatDate, formatWinRate, formatNumber } from "../utils/format"
import type { AchievementData, UserProfile } from "../types"

// ==========================================
// StatBlock Component
// ==========================================

interface StatBlockProps {
  icon: string
  label: string
  value: string | number
  subtext?: string
}

function StatBlock({ icon, label, value, subtext }: StatBlockProps) {
  return (
    <div className="flex flex-col items-center rounded-xl bg-[#1A1F2E] p-4">
      <span className="mb-1 text-2xl">{icon}</span>
      <span className="text-xs text-gray-400">{label}</span>
      <span className="text-xl font-bold text-white">{value}</span>
      {subtext && <span className="text-xs text-gray-500">{subtext}</span>}
    </div>
  )
}

// ==========================================
// ProfileHeader Component
// ==========================================

interface ProfileHeaderProps {
  profile: UserProfile
  xp: number
  level: number
}

function ProfileHeader({ profile, xp, level }: ProfileHeaderProps) {
  // Calculate XP progress (assuming 1000 XP per level)
  const xpForNextLevel = level * 1000
  const currentLevelXp = xp % 1000
  const xpProgress = (currentLevelXp / 1000) * 100

  return (
    <div className="flex flex-col items-center px-4 pb-6 pt-4">
      {/* Avatar */}
      <div className="relative mb-3">
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-[#FF6B35] to-[#e55a2a] text-3xl font-bold text-white">
          {profile.firstName.charAt(0).toUpperCase()}
        </div>
        {/* Level Badge */}
        <div className="absolute -bottom-1 -right-1 flex h-8 w-8 items-center justify-center rounded-full bg-[#FF6B35] text-sm font-bold text-white ring-2 ring-[#0F1419]">
          {level}
        </div>
      </div>

      {/* Username */}
      <h1 className="mb-1 text-xl font-bold text-white">
        {profile.username ? `@${profile.username}` : profile.firstName}
      </h1>

      {/* Join Date */}
      <p className="mb-4 text-sm text-gray-400">Joined {formatDate(profile.createdAt)}</p>

      {/* XP Progress Bar */}
      <div className="w-full max-w-xs">
        <div className="mb-1 flex justify-between text-xs text-gray-400">
          <span>Level {level}</span>
          <span>
            {currentLevelXp} / {1000} XP
          </span>
        </div>
        <div className="h-2 overflow-hidden rounded-full bg-[#1A1F2E]">
          <div
            className="h-full rounded-full bg-gradient-to-r from-[#FF6B35] to-[#e55a2a] transition-all duration-500"
            style={{ width: `${xpProgress}%` }}
          />
        </div>
      </div>
    </div>
  )
}

// ==========================================
// StatsSection Component
// ==========================================

interface StatsSectionProps {
  profile: UserProfile
  stats: {
    level: number
    xp: number
    totalWinnings: number
    winRate: number
  }
}

function StatsSection({ profile, stats }: StatsSectionProps) {
  return (
    <div className="px-4 pb-4">
      <h2 className="mb-3 text-lg font-semibold text-white">Stats</h2>
      <div className="grid grid-cols-3 gap-3">
        <StatBlock icon="🏆" label="Level" value={stats.level} />
        <StatBlock icon="⚡" label="XP" value={formatNumber(stats.xp)} />
        <StatBlock icon="🎯" label="Win Rate" value={formatWinRate(stats.winRate)} />
        <StatBlock icon="💰" label="Balance" value={formatBalance(profile.balance)} />
        <StatBlock icon="🪙" label="Coins" value={formatNumber(profile.coins)} />
        <StatBlock icon="💵" label="Winnings" value={formatBalance(stats.totalWinnings)} />
      </div>
    </div>
  )
}

// ==========================================
// AchievementGrid Component
// ==========================================

interface AchievementGridProps {
  achievements: AchievementData[]
}

function AchievementGrid({ achievements }: AchievementGridProps) {
  return (
    <div className="px-4 pb-6">
      <h2 className="mb-3 text-lg font-semibold text-white">Achievements</h2>
      <div className="grid grid-cols-4 gap-3">
        {achievements.map((achievement) => {
          const isUnlocked = achievement.unlockedAt !== null
          return (
            <div
              key={achievement.id}
              className={`flex flex-col items-center rounded-xl p-3 ${isUnlocked ? "bg-[#1A1F2E]" : "bg-[#1A1F2E]/50"}`}
            >
              <span className={`text-2xl ${isUnlocked ? "" : "grayscale opacity-50"}`}>{achievement.icon}</span>
              <span
                className={`mt-1 text-center text-xs ${isUnlocked ? "text-white" : "text-gray-500"}`}
                style={{ fontSize: "10px" }}
              >
                {achievement.name}
              </span>
              {!isUnlocked && achievement.progress > 0 && (
                <div className="mt-1 h-1 w-full overflow-hidden rounded-full bg-gray-700">
                  <div className="h-full bg-[#FF6B35]" style={{ width: `${achievement.progress}%` }} />
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ==========================================
// SettingsButton Component
// ==========================================

interface SettingsButtonProps {
  onLogout: () => void
}

function SettingsButton({ onLogout }: SettingsButtonProps) {
  return (
    <div className="px-4 pb-8">
      <button
        onClick={onLogout}
        className="w-full rounded-xl bg-[#1A1F2E] py-3 text-center text-red-400 transition-colors hover:bg-[#252A3A]"
      >
        Log Out
      </button>
    </div>
  )
}

// ==========================================
// Loading Skeleton
// ==========================================

function ProfileSkeleton() {
  return (
    <div className="animate-pulse">
      {/* Header skeleton */}
      <div className="flex flex-col items-center px-4 pb-6 pt-4">
        <div className="mb-3 h-20 w-20 rounded-full bg-[#1A1F2E]" />
        <div className="mb-2 h-6 w-32 rounded bg-[#1A1F2E]" />
        <div className="mb-4 h-4 w-24 rounded bg-[#1A1F2E]" />
        <div className="h-2 w-full max-w-xs rounded bg-[#1A1F2E]" />
      </div>

      {/* Stats skeleton */}
      <div className="px-4 pb-4">
        <div className="mb-3 h-5 w-16 rounded bg-[#1A1F2E]" />
        <div className="grid grid-cols-3 gap-3">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-24 rounded-xl bg-[#1A1F2E]" />
          ))}
        </div>
      </div>

      {/* Achievements skeleton */}
      <div className="px-4 pb-6">
        <div className="mb-3 h-5 w-28 rounded bg-[#1A1F2E]" />
        <div className="grid grid-cols-4 gap-3">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="h-20 rounded-xl bg-[#1A1F2E]" />
          ))}
        </div>
      </div>
    </div>
  )
}

// ==========================================
// Profile Page Component
// ==========================================

export function Profile() {
  const { user, logout } = useAuth()

  // Fetch profile
  const {
    data: profile,
    isLoading: profileLoading,
    error: profileError,
    refetch: refetchProfile,
  } = useQuery({
    queryKey: ["profile"],
    queryFn: getUserProfile,
    staleTime: 5 * 60 * 1000,
  })

  // Fetch stats
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["stats"],
    queryFn: getUserStats,
    staleTime: 5 * 60 * 1000,
  })

  // Fetch achievements
  const { data: achievements, isLoading: achievementsLoading } = useQuery({
    queryKey: ["achievements"],
    queryFn: getAchievements,
    staleTime: 10 * 60 * 1000,
  })

  const isLoading = profileLoading || statsLoading || achievementsLoading

  // Error state
  if (profileError) {
    return (
      <div className="flex h-full flex-col items-center justify-center p-4">
        <p className="mb-4 text-center text-gray-400">Failed to load profile</p>
        <button onClick={() => refetchProfile()} className="rounded-lg bg-[#FF6B35] px-4 py-2 font-medium text-white">
          Retry
        </button>
      </div>
    )
  }

  // Loading state
  if (isLoading || !profile || !stats) {
    return <ProfileSkeleton />
  }

  // Default achievements if none returned
  const displayAchievements = achievements || [
    {
      id: "1",
      name: "First Win",
      icon: "🏆",
      description: "Win your first bet",
      progress: 100,
      unlockedAt: new Date().toISOString(),
    },
    { id: "2", name: "Streak", icon: "🔥", description: "5 day streak", progress: 60, unlockedAt: null },
    { id: "3", name: "High Roller", icon: "💎", description: "Wager 10,000 NGN", progress: 25, unlockedAt: null },
    { id: "4", name: "Challenger", icon: "⚔️", description: "Win 10 challenges", progress: 30, unlockedAt: null },
    { id: "5", name: "Predictor", icon: "🎯", description: "Win 50 predictions", progress: 10, unlockedAt: null },
    { id: "6", name: "Social", icon: "👥", description: "Invite 5 friends", progress: 0, unlockedAt: null },
    { id: "7", name: "Veteran", icon: "🎖️", description: "Reach level 10", progress: 50, unlockedAt: null },
    { id: "8", name: "Lucky", icon: "🍀", description: "Win 3 in a row", progress: 66, unlockedAt: null },
  ]

  return (
    <div className="min-h-full bg-[#0F1419]">
      <ProfileHeader profile={profile} xp={stats.xp} level={stats.level} />
      <StatsSection profile={profile} stats={stats} />
      <AchievementGrid achievements={displayAchievements} />
      <SettingsButton onLogout={logout} />
    </div>
  )
}

export default Profile
