"use client"

import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { Layout } from "../src/components/Layout"
import { WalletPage } from "../src/pages/Wallet"

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 2,
      staleTime: 1000 * 60 * 5, // 5 minutes
      refetchOnWindowFocus: false,
    },
  },
})

export default function Page() {
  return (
    <QueryClientProvider client={queryClient}>
      <Layout>
        <WalletPage />
      </Layout>
    </QueryClientProvider>
  )
}
